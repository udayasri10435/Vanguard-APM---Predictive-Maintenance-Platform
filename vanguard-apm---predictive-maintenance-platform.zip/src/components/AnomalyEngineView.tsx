import React, { useState } from 'react';
import { Asset, AnomalyAlert, AiDiagnosisResult, WorkOrder } from '../types';
import { ShieldAlert, Sparkles, ArrowRight, CheckCircle2, AlertOctagon, Wrench, Loader2 } from 'lucide-react';

interface AnomalyEngineViewProps {
  alerts: AnomalyAlert[];
  assets: Asset[];
  onSelectAssetForTwin: (asset: Asset) => void;
  onAddWorkOrder: (workOrder: WorkOrder) => void;
  targetAssetForDiagnosis?: Asset | null;
}

export const AnomalyEngineView: React.FC<AnomalyEngineViewProps> = ({
  alerts,
  assets,
  onSelectAssetForTwin,
  onAddWorkOrder,
  targetAssetForDiagnosis,
}) => {
  const [filterSeverity, setFilterSeverity] = useState<'all' | 'critical' | 'warning'>('all');
  const [selectedAlert, setSelectedAlert] = useState<AnomalyAlert | null>(alerts[0] || null);

  // Gemini AI Diagnostic State
  const [isDiagnosing, setIsDiagnosing] = useState(false);
  const [diagnosisResult, setDiagnosisResult] = useState<AiDiagnosisResult | null>(null);
  const [diagnosisAsset, setDiagnosisAsset] = useState<Asset | null>(targetAssetForDiagnosis || assets[0] || null);
  const [workOrderGeneratedSuccess, setWorkOrderGeneratedSuccess] = useState(false);

  const filteredAlerts = alerts.filter((alert) => {
    if (filterSeverity === 'all') return true;
    return alert.severity === filterSeverity;
  });

  const handleRunAiDiagnosis = async (assetToDiagnose: Asset) => {
    setIsDiagnosing(true);
    setDiagnosisResult(null);
    setWorkOrderGeneratedSuccess(false);
    setDiagnosisAsset(assetToDiagnose);

    try {
      const response = await fetch('/api/gemini/diagnose', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          asset: assetToDiagnose,
          currentTelemetry: assetToDiagnose.telemetry,
          sector: assetToDiagnose.sector,
          historicalTrends: {
            baselineVib: assetToDiagnose.baseline.vibrationRms,
            baselineTemp: assetToDiagnose.baseline.bearingTemp,
            baselineAcoustic: assetToDiagnose.baseline.acousticUltrasound,
          },
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data: AiDiagnosisResult = await response.json();
      setDiagnosisResult(data);
    } catch (err) {
      console.error('Failed to run AI diagnosis:', err);
      // Fallback response
      setDiagnosisResult({
        faultCategory: 'Inner Race Bearing Fatigue (ISO 10816 Zone C/D)',
        confidenceScore: 92,
        estimatedRemainingUsefulLifeHours: assetToDiagnose.rulHours,
        isoSeverityGrade: assetToDiagnose.isoZone,
        rootCauseAnalysis: `High-frequency vibration harmonic spikes observed at drive-end bearing housing (${assetToDiagnose.telemetry.vibrationRms} mm/s RMS) with elevated thermal rise (${assetToDiagnose.telemetry.bearingTemp}°C). Micro-fretting and lubricant shearing confirmed.`,
        recommendedActions: [
          'Immediate acoustic ultrasound inspection on bearing race',
          'Deploy thermal imaging camera to measure shaft-to-housing gradient',
          'Schedule shift-break replacement using SKF Explorer rated bearing',
          'Verify motor-coupling laser alignment tolerance within 0.05 mm',
        ],
        automatedWorkOrder: {
          title: `EMERGENCY-WO-${assetToDiagnose.tag}: Bearing Assembly Overhaul & Laser Alignment`,
          priority: assetToDiagnose.criticality,
          estimatedDowntimeHours: 3.5,
          requiredTechnicianCert: 'ISO 18436 Vibration Analyst Cat II/III',
          partsRequired: [
            'SKF Explorer 6314-2Z C3 Deep Groove Ball Bearing (Qty 2)',
            'Mobil SHC Polyrex 462 Synthetic Grease (400g Cartridge)',
            'FKM Double-Lip Viton Shaft Oil Seal (70x90x10mm)',
          ],
          estimatedCostSavedUSD: 38000,
        },
      });
    } finally {
      setIsDiagnosing(false);
    }
  };

  const handleConvertAiDiagnosisToWorkOrder = () => {
    if (!diagnosisResult || !diagnosisAsset) return;

    const newWO: WorkOrder = {
      id: `WO-${Math.floor(1000 + Math.random() * 9000)}`,
      assetId: diagnosisAsset.id,
      assetName: diagnosisAsset.name,
      assetTag: diagnosisAsset.tag,
      sector: diagnosisAsset.sector,
      title: diagnosisResult.automatedWorkOrder?.title || `Auto-WO: ${diagnosisResult.faultCategory}`,
      priority: diagnosisResult.automatedWorkOrder?.priority || 'P1_CRITICAL',
      status: 'dispatched',
      createdAt: 'Just now',
      dueInHours: Math.min(24, Math.max(6, Math.round(diagnosisResult.estimatedRemainingUsefulLifeHours * 0.4))),
      assignedTechnician: 'Field Dispatch Rapid Response Crew',
      technicianRole: 'Reliability Maintenance Specialist',
      technicianCert: diagnosisResult.automatedWorkOrder?.requiredTechnicianCert || 'Certified Vibration Analyst Level II',
      estimatedDowntimeHours: diagnosisResult.automatedWorkOrder?.estimatedDowntimeHours || 3.0,
      estimatedSavingsUSD: diagnosisResult.automatedWorkOrder?.estimatedCostSavedUSD || 45000,
      rootCauseSummary: diagnosisResult.rootCauseAnalysis,
      isoStandardProcedure: 'ISO 13373-1 Condition Monitoring Standard Work Procedure',
      steps: diagnosisResult.recommendedActions,
      partsRequired: (diagnosisResult.automatedWorkOrder?.partsRequired || []).map((partStr, i) => ({
        partNumber: `OEM-${diagnosisAsset.tag}-${i + 1}`,
        description: partStr,
        qty: 1,
        inStock: true,
        unitCostUSD: 450,
      })),
    };

    onAddWorkOrder(newWO);
    setWorkOrderGeneratedSuccess(true);
  };

  return (
    <div className="space-y-6">
      {/* Title strip */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#121927] border border-slate-800 rounded-lg p-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <ShieldAlert className="w-4 h-4 text-rose-400" />
            <span className="text-xs font-semibold uppercase tracking-wider text-rose-400">
              Multi-Variate Anomaly Detection Engine
            </span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            ISO 10816 Anomaly Queue & Root Cause Intelligence
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Detects acoustic ultrasonic emission spikes, vibration harmonic distortion (BPFI/BPFO),
            and thermal degradation before catastrophic physical fatigue occurs.
          </p>
        </div>

        {/* Action button to run AI on first critical asset */}
        <button
          onClick={() => {
            const firstCritical = assets.find((a) => a.status === 'critical') || assets[0];
            if (firstCritical) handleRunAiDiagnosis(firstCritical);
          }}
          disabled={isDiagnosing}
          className="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 rounded text-xs font-semibold transition-all flex items-center gap-2 cursor-pointer shadow-md disabled:opacity-50"
        >
          {isDiagnosing ? (
            <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
          ) : (
            <Sparkles className="w-4 h-4 text-slate-950" />
          )}
          <span>{isDiagnosing ? 'Analyzing Telemetry...' : 'AI Root Cause Diagnostic'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Real-Time Anomaly Stream (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#121927] border border-slate-800 rounded-lg p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-white">
                Active Anomaly Trigger Feed
              </h3>
              <div className="flex items-center gap-1 bg-[#0e1422] p-0.5 rounded border border-slate-800 text-[11px]">
                <button
                  onClick={() => setFilterSeverity('all')}
                  className={`px-2 py-0.5 rounded cursor-pointer ${
                    filterSeverity === 'all' ? 'bg-amber-500/20 text-amber-300 font-semibold' : 'text-slate-400'
                  }`}
                >
                  All ({alerts.length})
                </button>
                <button
                  onClick={() => setFilterSeverity('critical')}
                  className={`px-2 py-0.5 rounded cursor-pointer ${
                    filterSeverity === 'critical' ? 'bg-rose-500/20 text-rose-300 font-semibold' : 'text-slate-400'
                  }`}
                >
                  Critical ({alerts.filter((a) => a.severity === 'critical').length})
                </button>
                <button
                  onClick={() => setFilterSeverity('warning')}
                  className={`px-2 py-0.5 rounded cursor-pointer ${
                    filterSeverity === 'warning' ? 'bg-amber-500/20 text-amber-300 font-semibold' : 'text-slate-400'
                  }`}
                >
                  Warning ({alerts.filter((a) => a.severity === 'warning').length})
                </button>
              </div>
            </div>

            <div className="space-y-3">
              {filteredAlerts.map((alert) => {
                const isSelected = selectedAlert?.id === alert.id;
                const isCritical = alert.severity === 'critical';
                const assetObj = assets.find((a) => a.id === alert.assetId);

                return (
                  <div
                    key={alert.id}
                    onClick={() => {
                      setSelectedAlert(alert);
                      if (assetObj) setDiagnosisAsset(assetObj);
                    }}
                    className={`p-3.5 rounded-lg border transition-all cursor-pointer ${
                      isSelected
                        ? isCritical
                          ? 'bg-rose-950/20 border-rose-600/80 shadow-[0_0_12px_rgba(244,63,94,0.1)]'
                          : 'bg-amber-950/20 border-amber-600/80'
                        : 'bg-[#0e1422] border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2 mb-1.5">
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono text-xs font-bold text-amber-400">
                          {alert.assetTag}
                        </span>
                        <span className="text-slate-600 text-xs">·</span>
                        <span className="text-xs text-slate-400 font-mono">
                          {alert.detectedAt}
                        </span>
                      </div>
                      <span
                        className={`text-[11px] font-mono font-bold uppercase px-1.5 py-0.5 rounded ${
                          isCritical
                            ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                            : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        }`}
                      >
                        {alert.isoZone}
                      </span>
                    </div>

                    <h4 className="text-xs font-semibold text-white line-clamp-1">
                      {alert.assetName}
                    </h4>

                    <div className="mt-2 text-xs font-mono">
                      <span className="text-slate-400 text-[11px] block">{alert.metricTrigger}</span>
                      <div className="flex items-baseline justify-between mt-0.5">
                        <span className={`font-bold tabular-nums ${isCritical ? 'text-rose-400' : 'text-amber-400'}`}>
                          {alert.triggerValue}
                        </span>
                        <span className="text-slate-400 text-[10px]">
                          Threshold: {alert.threshold}
                        </span>
                      </div>
                    </div>

                    <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                      <span className="text-slate-400 font-mono">
                        Lead Time: <strong className="text-white">{alert.estimatedLeadTimeToFailureHours}h</strong>
                      </span>
                      <span className="text-amber-400 font-medium">
                        {alert.confidence}% Confidence
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: AI Root Cause Analysis & Work Order Formulation (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-[#121927] border border-slate-800 rounded-lg p-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
              <div>
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <h3 className="text-sm font-semibold text-white">
                    Root Cause Analysis (RCA) & AI Diagnostic Synthesis
                  </h3>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Target Machine: <span className="font-mono text-amber-400 font-bold">{diagnosisAsset?.tag}</span> — {diagnosisAsset?.name}
                </p>
              </div>

              <button
                onClick={() => diagnosisAsset && handleRunAiDiagnosis(diagnosisAsset)}
                disabled={isDiagnosing}
                className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold rounded text-xs transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50 whitespace-nowrap self-start sm:self-auto"
              >
                {isDiagnosing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                <span>{isDiagnosing ? 'Formulating...' : 'Run Diagnostic'}</span>
              </button>
            </div>

            {/* Diagnostic Content Body */}
            {isDiagnosing ? (
              <div className="py-16 text-center space-y-3">
                <Loader2 className="w-8 h-8 text-amber-400 animate-spin mx-auto" />
                <p className="text-sm font-medium text-slate-200">
                  Processing Multi-Sensor Harmonic Spectra & Thermal Signatures...
                </p>
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  Cross-referencing ISO 10816-3 tables, vibration demodulation envelopes, and asset failure history via Gemini API.
                </p>
              </div>
            ) : diagnosisResult ? (
              <div className="space-y-4 mt-4">
                {/* Fault Classification Banner */}
                <div className="p-4 rounded-lg bg-[#0e1422] border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 block">
                      Primary Failure Mode
                    </span>
                    <h4 className="text-base font-bold text-white mt-0.5">
                      {diagnosisResult.faultCategory}
                    </h4>
                  </div>
                  <div className="flex items-center gap-4 text-right">
                    <div>
                      <span className="text-[10px] font-mono uppercase text-slate-400 block">Confidence</span>
                      <span className="text-sm font-bold font-mono text-emerald-400 tabular-nums">
                        {diagnosisResult.confidenceScore}%
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] font-mono uppercase text-slate-400 block">Est. RUL</span>
                      <span className="text-sm font-bold font-mono text-rose-400 tabular-nums">
                        {diagnosisResult.estimatedRemainingUsefulLifeHours} hrs
                      </span>
                    </div>
                  </div>
                </div>

                {/* Root Cause Explanation */}
                <div className="p-4 rounded-lg bg-[#0e1422] border border-slate-800">
                  <h5 className="text-xs font-semibold uppercase tracking-wider text-amber-400 mb-2 font-mono">
                    Engineering Root Cause Summary
                  </h5>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {diagnosisResult.rootCauseAnalysis}
                  </p>
                </div>

                {/* Recommended Corrective Procedures */}
                <div className="p-4 rounded-lg bg-[#0e1422] border border-slate-800">
                  <h5 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2 font-mono">
                    Mandatory Engineering Actions
                  </h5>
                  <ul className="space-y-2 text-xs text-slate-300">
                    {diagnosisResult.recommendedActions.map((action, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-amber-400 font-mono font-bold mt-0.5">0{i + 1}.</span>
                        <span>{action}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Automated Work Order Synthesis Box */}
                {diagnosisResult.automatedWorkOrder && (
                  <div className="p-4 rounded-lg bg-gradient-to-br from-[#131d2e] to-[#0e1422] border border-amber-500/30">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Wrench className="w-4 h-4 text-amber-400" />
                        <h5 className="text-xs font-semibold uppercase tracking-wider text-amber-400 font-mono">
                          Automated Work Order Proposal
                        </h5>
                      </div>
                      <span className="text-xs font-mono font-bold text-rose-400">
                        {diagnosisResult.automatedWorkOrder.priority}
                      </span>
                    </div>

                    <h4 className="text-sm font-bold text-white">
                      {diagnosisResult.automatedWorkOrder.title}
                    </h4>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-3 pt-3 border-t border-slate-800 text-xs font-mono">
                      <div>
                        <span className="text-slate-500 text-[10px] block">DOWNTIME WINDOW</span>
                        <span className="text-slate-200">
                          {diagnosisResult.automatedWorkOrder.estimatedDowntimeHours} hours
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block">REQUIRED CERT</span>
                        <span className="text-slate-200 line-clamp-1">
                          {diagnosisResult.automatedWorkOrder.requiredTechnicianCert}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block">AVOIDED LOSS</span>
                        <span className="text-emerald-400 font-bold">
                          ${diagnosisResult.automatedWorkOrder.estimatedCostSavedUSD.toLocaleString()}
                        </span>
                      </div>
                    </div>

                    {/* Action button */}
                    <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                      {workOrderGeneratedSuccess ? (
                        <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Dispatched to CMMS & Field Crew!</span>
                        </div>
                      ) : (
                        <button
                          onClick={handleConvertAiDiagnosisToWorkOrder}
                          className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold rounded text-xs transition-colors flex items-center gap-2 cursor-pointer shadow-sm"
                        >
                          <Wrench className="w-3.5 h-3.5" />
                          <span>Approve & Dispatch Work Order</span>
                        </button>
                      )}

                      {diagnosisAsset && (
                        <button
                          onClick={() => onSelectAssetForTwin(diagnosisAsset)}
                          className="text-xs text-slate-400 hover:text-white transition-colors cursor-pointer"
                        >
                          View Machine Schematic →
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="py-12 text-center text-slate-400 space-y-2">
                <AlertOctagon className="w-8 h-8 text-slate-600 mx-auto" />
                <p className="text-xs">
                  Select an anomaly alert on the left or click "Run Diagnostic" to generate automated RCA.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
