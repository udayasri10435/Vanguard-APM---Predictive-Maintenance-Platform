import React from 'react';
import { Play, Pause, Zap } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isStreaming: boolean;
  setIsStreaming: (streaming: boolean | ((prev: boolean) => boolean)) => void;
  onOpenFaultModal: () => void;
  criticalAlertCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  isStreaming,
  setIsStreaming,
  onOpenFaultModal,
  criticalAlertCount,
}) => {
  const navItems = [
    { id: 'overview', label: 'Fleet Overview' },
    { id: 'twin', label: 'Digital Twins' },
    { id: 'anomalies', label: 'Anomaly Engine', count: criticalAlertCount },
    { id: 'work-orders', label: 'Work Orders' },
    { id: 'gateway', label: 'IoT Gateway' },
    { id: 'roi', label: 'ROI & Value' },
  ];

  return (
    <header className="border-b border-slate-800 bg-[#0e1422] sticky top-0 z-40 px-6 py-3.5">
      <div className="flex items-center justify-between max-w-[1600px] mx-auto">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center font-bold text-black font-mono shadow-sm">
            V
          </div>
          <span className="text-lg font-bold tracking-tight text-white font-sans">
            Vanguard APM
          </span>
        </div>

        {/* Zone 2: Clean text navigation links with subtle hover underlines */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`relative py-1 text-sm transition-colors cursor-pointer flex items-center gap-1.5 ${
                  isActive
                    ? 'text-amber-400 font-semibold after:absolute after:bottom-[-14px] after:left-0 after:right-0 after:h-[2px] after:bg-amber-400'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <span>{item.label}</span>
                {item.count !== undefined && item.count > 0 && (
                  <span className="text-[11px] font-mono tabular-nums text-rose-400 font-bold ml-0.5">
                    ({item.count})
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary action controls */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsStreaming((prev) => !prev)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs font-mono tabular-nums transition-colors border cursor-pointer ${
              isStreaming
                ? 'bg-emerald-950/40 text-emerald-300 border-emerald-800/60 hover:bg-emerald-900/50'
                : 'bg-slate-900 text-slate-400 border-slate-700 hover:text-slate-200'
            }`}
            title="Toggle live simulated IoT sensor stream"
          >
            {isStreaming ? (
              <>
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <span>STREAM: 1 Hz</span>
                <Pause className="w-3.5 h-3.5 ml-1" />
              </>
            ) : (
              <>
                <span className="h-2 w-2 rounded-full bg-slate-500"></span>
                <span>STREAM: PAUSED</span>
                <Play className="w-3.5 h-3.5 ml-1" />
              </>
            )}
          </button>

          <button
            onClick={onOpenFaultModal}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold rounded text-xs font-sans transition-colors shadow-sm cursor-pointer whitespace-nowrap"
          >
            <Zap className="w-3.5 h-3.5 text-slate-950" />
            <span>Inject Fault</span>
          </button>
        </div>
      </div>
    </header>
  );
};
