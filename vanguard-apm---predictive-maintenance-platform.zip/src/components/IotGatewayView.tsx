import React, { useState, useEffect } from 'react';
import { Asset, IngestionPacket } from '../types';
import { Cpu, Send, CheckCircle2, AlertTriangle, ShieldCheck, Terminal, Server, Wifi } from 'lucide-react';

interface IotGatewayViewProps {
  assets: Asset[];
  isStreaming: boolean;
  onUpdateAssetTelemetry: (assetId: string, telemetry: any) => void;
}

export const IotGatewayView: React.FC<IotGatewayViewProps> = ({
  assets,
  isStreaming,
  onUpdateAssetTelemetry,
}) => {
  const [packets, setPackets] = useState<IngestionPacket[]>([]);
  const [selectedAssetId, setSelectedAssetId] = useState(assets[0]?.id || '');
  const [protocol, setProtocol] = useState<'MQTT_v5' | 'OPC_UA' | 'MODBUS_TCP' | 'SPARKPLUG_B'>('MQTT_v5');

  // Interactive Test Payload Form
  const [testVibration, setTestVibration] = useState('6.85');
  const [testTemp, setTestTemp] = useState('81.2');
  const [testAcoustic, setTestAcoustic] = useState('54.0');
  const [pushStatus, setPushStatus] = useState<any | null>(null);
  const [isPushing, setIsPushing] = useState(false);

  // Initialize and simulate incoming high-frequency packets
  useEffect(() => {
    const protocols: ('MQTT_v5' | 'OPC_UA' | 'MODBUS_TCP' | 'SPARKPLUG_B')[] = [
      'MQTT_v5',
      'OPC_UA',
      'SPARKPLUG_B',
      'MODBUS_TCP',
    ];

    const initialPackets: IngestionPacket[] = Array.from({ length: 12 }).map((_, i) => {
      const a = assets[i % assets.length];
      const proto = protocols[i % protocols.length];
      const score = a.status === 'critical' ? 82 : a.status === 'warning' ? 48 : 12;
      return {
        id: `PKT-${9000 + i}`,
        timestamp: new Date(Date.now() - (12 - i) * 1200).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        assetId: a.tag,
        protocol: proto,
        payloadSizeKb: Number((1.2 + Math.random() * 0.8).toFixed(1)),
        latencyMs: Math.round(2.5 + Math.random() * 4),
        anomalyScore: score,
        status: score > 70 ? 'ALERT_TRIPPED' : score > 40 ? 'THRESHOLD_WARNING' : 'ACCEPTED',
      };
    });
    setPackets(initialPackets);
  }, [assets]);

  // Push new packet every 1.5 seconds if streaming
  useEffect(() => {
    if (!isStreaming) return;
    const interval = setInterval(() => {
      const randomAsset = assets[Math.floor(Math.random() * assets.length)];
      const proto: any = ['MQTT_v5', 'SPARKPLUG_B', 'OPC_UA'][Math.floor(Math.random() * 3)];
      const score = randomAsset.status === 'critical' ? 85 : randomAsset.status === 'warning' ? 52 : 11;

      const newPacket: IngestionPacket = {
        id: `PKT-${Math.floor(10000 + Math.random() * 90000)}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        assetId: randomAsset.tag,
        protocol: proto,
        payloadSizeKb: Number((1.2 + Math.random() * 0.9).toFixed(1)),
        latencyMs: Math.round(2.1 + Math.random() * 3.5),
        anomalyScore: score,
        status: score > 70 ? 'ALERT_TRIPPED' : score > 40 ? 'THRESHOLD_WARNING' : 'ACCEPTED',
      };

      setPackets((prev) => [newPacket, ...prev.slice(0, 19)]);
    }, 1500);

    return () => clearInterval(interval);
  }, [isStreaming, assets]);

  // Transmit live test batch to server endpoint /api/ingestion/push
  const handleTransmitPayload = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsPushing(true);
    setPushStatus(null);

    const assetObj = assets.find((a) => a.id === selectedAssetId) || assets[0];

    try {
      const payload = {
        assetId: assetObj.tag,
        timestamp: new Date().toISOString(),
        protocol,
        telemetry: {
          vibrationRms: parseFloat(testVibration) || 1.8,
          temperature: parseFloat(testTemp) || 55,
          acousticUltrasound: parseFloat(testAcoustic) || 20,
        },
      };

      const res = await fetch('/api/ingestion/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      setPushStatus(data);

      // Update in memory telemetry state
      onUpdateAssetTelemetry(assetObj.id, {
        vibrationRms: parseFloat(testVibration),
        bearingTemp: parseFloat(testTemp),
        acousticUltrasound: parseFloat(testAcoustic),
      });

      // Add to packet stream
      const newPacket: IngestionPacket = {
        id: `PKT-${Math.floor(10000 + Math.random() * 90000)}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        assetId: assetObj.tag,
        protocol,
        payloadSizeKb: 1.8,
        latencyMs: 3.2,
        anomalyScore: data.anomalyScore,
        status: data.anomalyScore > 70 ? 'ALERT_TRIPPED' : data.anomalyScore > 40 ? 'THRESHOLD_WARNING' : 'ACCEPTED',
      };
      setPackets((prev) => [newPacket, ...prev.slice(0, 19)]);
    } catch (err: any) {
      console.error('Failed to transmit batch:', err);
    } finally {
      setIsPushing(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#121927] border border-slate-800 rounded-lg p-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Cpu className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-semibold uppercase tracking-wider text-emerald-400">
              Edge IoT Sensor Ingestion Gateway
            </span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            High-Throughput Telemetry Stream Pipeline
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Ingests high-rate industrial edge streams via MQTT v5, Sparkplug B, OPC UA, and Modbus TCP.
            Real-time threshold validation and multi-variate score pipeline executing at sub-5ms latency.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 border border-slate-800 rounded text-xs font-mono text-slate-300">
            <Wifi className="w-3.5 h-3.5 text-emerald-400" />
            <span>GATEWAY: CONNECTED</span>
          </div>
        </div>
      </div>

      {/* Gateway Telemetry Metrics Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 bg-[#121927] border border-slate-800 rounded-lg">
          <span className="text-[10px] font-mono uppercase text-slate-400 block mb-1">
            Ingestion Throughput
          </span>
          <span className="text-xl font-bold font-mono tabular-nums text-white">
            1,480 <span className="text-xs text-slate-400 font-normal">msgs/sec</span>
          </span>
          <span className="text-[11px] text-emerald-400 block mt-1 font-mono">
            Zero packet loss (0.00%)
          </span>
        </div>

        <div className="p-4 bg-[#121927] border border-slate-800 rounded-lg">
          <span className="text-[10px] font-mono uppercase text-slate-400 block mb-1">
            Mean Parsing Latency
          </span>
          <span className="text-xl font-bold font-mono tabular-nums text-emerald-400">
            3.4 <span className="text-xs text-slate-400 font-normal">ms</span>
          </span>
          <span className="text-[11px] text-slate-400 block mt-1 font-mono">
            Edge sub-sampling active
          </span>
        </div>

        <div className="p-4 bg-[#121927] border border-slate-800 rounded-lg">
          <span className="text-[10px] font-mono uppercase text-slate-400 block mb-1">
            Active Industrial Brokers
          </span>
          <span className="text-xl font-bold font-mono tabular-nums text-white">
            4 <span className="text-xs text-slate-400 font-normal">Protocols</span>
          </span>
          <span className="text-[11px] text-amber-400 block mt-1 font-mono">
            MQTT · Sparkplug · OPC · Modbus
          </span>
        </div>

        <div className="p-4 bg-[#121927] border border-slate-800 rounded-lg">
          <span className="text-[10px] font-mono uppercase text-slate-400 block mb-1">
            Server API Endpoint
          </span>
          <span className="text-xs font-mono font-bold text-white block truncate">
            POST /api/ingestion/push
          </span>
          <span className="text-[11px] text-slate-400 block mt-1 font-mono">
            Edge Authentication Active
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Live Ingestion Stream Feed (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-[#121927] border border-slate-800 rounded-lg p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-semibold text-white">
                  Live Sensor Ingestion Stream Buffer
                </h3>
              </div>
              <span className="text-xs font-mono text-slate-400">
                Latest 20 frames
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs font-mono text-left">
                <thead>
                  <tr className="text-slate-500 border-b border-slate-800 text-[10px]">
                    <th className="pb-2">TIME</th>
                    <th className="pb-2">PACKET ID</th>
                    <th className="pb-2">ASSET TAG</th>
                    <th className="pb-2">PROTOCOL</th>
                    <th className="pb-2 text-right">SIZE</th>
                    <th className="pb-2 text-right">LATENCY</th>
                    <th className="pb-2 text-right">STATUS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {packets.map((pkt) => (
                    <tr key={pkt.id} className="text-slate-300 hover:bg-slate-800/30">
                      <td className="py-2 text-slate-400">{pkt.timestamp}</td>
                      <td className="py-2 text-slate-400 font-bold">{pkt.id}</td>
                      <td className="py-2 text-amber-400 font-bold">{pkt.assetId}</td>
                      <td className="py-2 text-slate-300">{pkt.protocol}</td>
                      <td className="py-2 text-right tabular-nums">{pkt.payloadSizeKb} KB</td>
                      <td className="py-2 text-right tabular-nums text-slate-400">{pkt.latencyMs}ms</td>
                      <td className="py-2 text-right">
                        <span
                          className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            pkt.status === 'ALERT_TRIPPED'
                              ? 'bg-rose-950 text-rose-300 border border-rose-800'
                              : pkt.status === 'THRESHOLD_WARNING'
                              ? 'bg-amber-950 text-amber-300 border border-amber-800'
                              : 'bg-emerald-950 text-emerald-300'
                          }`}
                        >
                          {pkt.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right Column: Interactive Edge Ingestion Simulator (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#121927] border border-slate-800 rounded-lg p-5">
            <div className="flex items-center gap-2 mb-3">
              <Server className="w-4 h-4 text-amber-400" />
              <h3 className="text-sm font-semibold text-white">
                Transmit Simulated IoT Batch
              </h3>
            </div>
            <p className="text-xs text-slate-400 mb-4">
              Test how the edge pipeline ingests custom telemetry, evaluates ISO vibration criteria,
              and auto-trips maintenance work orders.
            </p>

            <form onSubmit={handleTransmitPayload} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 font-medium mb-1">Target Asset</label>
                <select
                  value={selectedAssetId}
                  onChange={(e) => setSelectedAssetId(e.target.value)}
                  className="w-full bg-[#0e1422] border border-slate-700 text-white rounded p-2 focus:outline-none focus:border-amber-500 font-mono"
                >
                  {assets.map((a) => (
                    <option key={a.id} value={a.id}>
                      [{a.tag}] {a.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Industrial Protocol</label>
                <select
                  value={protocol}
                  onChange={(e) => setProtocol(e.target.value as any)}
                  className="w-full bg-[#0e1422] border border-slate-700 text-white rounded p-2 focus:outline-none focus:border-amber-500 font-mono"
                >
                  <option value="MQTT_v5">MQTT v5.0 (QoS 1)</option>
                  <option value="SPARKPLUG_B">MQTT Sparkplug B Edge</option>
                  <option value="OPC_UA">OPC UA Binary (TCP Port 4840)</option>
                  <option value="MODBUS_TCP">Modbus TCP Industrial Gateway</option>
                </select>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Vibration (mm/s)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={testVibration}
                    onChange={(e) => setTestVibration(e.target.value)}
                    className="w-full bg-[#0e1422] border border-slate-700 text-white rounded p-2 focus:outline-none focus:border-amber-500 font-mono"
                  />
                  <span className="text-[10px] text-slate-500 block mt-0.5">Critical: &gt;7.1</span>
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">Temp (°C)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={testTemp}
                    onChange={(e) => setTestTemp(e.target.value)}
                    className="w-full bg-[#0e1422] border border-slate-700 text-white rounded p-2 focus:outline-none focus:border-amber-500 font-mono"
                  />
                  <span className="text-[10px] text-slate-500 block mt-0.5">Critical: &gt;85</span>
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">Acoustic (dB)</label>
                  <input
                    type="number"
                    step="1"
                    value={testAcoustic}
                    onChange={(e) => setTestAcoustic(e.target.value)}
                    className="w-full bg-[#0e1422] border border-slate-700 text-white rounded p-2 focus:outline-none focus:border-amber-500 font-mono"
                  />
                  <span className="text-[10px] text-slate-500 block mt-0.5">Critical: &gt;60</span>
                </div>
              </div>

              <button
                type="submit"
                disabled={isPushing}
                className="w-full py-2 px-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold rounded text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50 mt-4"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isPushing ? 'Transmitting Ingestion Payload...' : 'Push Telemetry Batch'}</span>
              </button>
            </form>

            {/* Ingestion Response Box */}
            {pushStatus && (
              <div className="mt-4 p-3 bg-[#0e1422] rounded border border-slate-800 text-xs font-mono space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">INGESTION STATUS:</span>
                  <span className="text-emerald-400 font-bold">{pushStatus.status}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">ANOMALY SCORE:</span>
                  <span
                    className={`font-bold tabular-nums ${
                      pushStatus.anomalyScore > 70
                        ? 'text-rose-400'
                        : pushStatus.anomalyScore > 40
                        ? 'text-amber-400'
                        : 'text-emerald-400'
                    }`}
                  >
                    {pushStatus.anomalyScore} / 100
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">SEVERITY CLASSIFICATION:</span>
                  <span className="text-slate-200">{pushStatus.severity}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">WORK ORDER AUTO-TRIGGER:</span>
                  <span
                    className={
                      pushStatus.autoWorkOrderTriggered
                        ? 'text-rose-400 font-bold'
                        : 'text-slate-400'
                    }
                  >
                    {pushStatus.autoWorkOrderTriggered ? 'YES (THRESHOLD BREACH)' : 'NO (WITHIN TOLERANCE)'}
                  </span>
                </div>
                {pushStatus.flags && pushStatus.flags.length > 0 && (
                  <div className="pt-2 border-t border-slate-800/80">
                    <span className="text-slate-500 text-[10px] block mb-1">TRIGGERED EDGE FLAGS:</span>
                    <div className="flex flex-wrap gap-1">
                      {pushStatus.flags.map((flag: string, i: number) => (
                        <span key={i} className="text-[10px] bg-rose-950/80 text-rose-300 px-1.5 py-0.5 rounded border border-rose-900">
                          {flag}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
