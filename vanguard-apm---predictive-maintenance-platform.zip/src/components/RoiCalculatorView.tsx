import React, { useState } from 'react';
import { Sector } from '../types';
import { DollarSign, TrendingUp, ShieldCheck, Clock, Award, Building2, Zap, Truck } from 'lucide-react';

export const RoiCalculatorView: React.FC = () => {
  const [sectorPreset, setSectorPreset] = useState<Sector>('plants');
  const [criticalMachines, setCriticalMachines] = useState(25);
  const [downtimeCostPerHour, setDowntimeCostPerHour] = useState(18500);
  const [unplannedOutageHoursPerYear, setUnplannedOutageHoursPerYear] = useState(48);
  const [preventedFailureRate, setPreventedFailureRate] = useState(75);

  const applyPreset = (sector: Sector) => {
    setSectorPreset(sector);
    if (sector === 'plants') {
      setCriticalMachines(30);
      setDowntimeCostPerHour(16000);
      setUnplannedOutageHoursPerYear(54);
    } else if (sector === 'utilities') {
      setCriticalMachines(12);
      setDowntimeCostPerHour(58000);
      setUnplannedOutageHoursPerYear(28);
    } else if (sector === 'fleets') {
      setCriticalMachines(80);
      setDowntimeCostPerHour(4200);
      setUnplannedOutageHoursPerYear(110);
    }
  };

  // Calculations
  const grossDowntimeCost = downtimeCostPerHour * unplannedOutageHoursPerYear;
  const avoidedDowntimeCost = grossDowntimeCost * (preventedFailureRate / 100);
  const avoidedCatastrophicPartsCost = criticalMachines * 14500 * (preventedFailureRate / 100);
  const totalAnnualSavings = avoidedDowntimeCost + avoidedCatastrophicPartsCost;
  const estimatedPlatformCost = criticalMachines * 1200 + 15000;
  const netRoiPercentage = Math.round(((totalAnnualSavings - estimatedPlatformCost) / estimatedPlatformCost) * 100);
  const paybackMonths = Number(((estimatedPlatformCost / totalAnnualSavings) * 12).toFixed(1));

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#121927] border border-slate-800 rounded-lg p-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <DollarSign className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-semibold uppercase tracking-wider text-emerald-400">
              Reliability ROI & Economic Impact Modeling
            </span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            Financial Justification for Plants, Utilities & Fleets
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Model the tangible cost savings of shifting from reactive emergency breakdown maintenance
            to autonomous vibration & thermal predictive condition dispatch.
          </p>
        </div>

        {/* Sector Presets */}
        <div className="flex items-center gap-1 bg-[#0e1422] p-1 rounded-lg border border-slate-800">
          <button
            onClick={() => applyPreset('plants')}
            className={`px-3 py-1.5 rounded text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
              sectorPreset === 'plants' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'text-slate-400'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>Industrial Plants</span>
          </button>
          <button
            onClick={() => applyPreset('utilities')}
            className={`px-3 py-1.5 rounded text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
              sectorPreset === 'utilities' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'text-slate-400'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Power Utilities</span>
          </button>
          <button
            onClick={() => applyPreset('fleets')}
            className={`px-3 py-1.5 rounded text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
              sectorPreset === 'fleets' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'text-slate-400'
            }`}
          >
            <Truck className="w-3.5 h-3.5" />
            <span>Logistics Fleets</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Inputs (Left) and Financial Return (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Interactive Parametric Sliders (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#121927] border border-slate-800 rounded-lg p-5 space-y-5">
            <h3 className="text-sm font-semibold text-white">
              Operational Input Parameters
            </h3>

            {/* Slider 1: Critical Assets */}
            <div>
              <div className="flex justify-between text-xs font-mono mb-1.5">
                <span className="text-slate-400">Critical Monitored Assets</span>
                <span className="text-amber-400 font-bold">{criticalMachines} units</span>
              </div>
              <input
                type="range"
                min="5"
                max="150"
                value={criticalMachines}
                onChange={(e) => setCriticalMachines(Number(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            {/* Slider 2: Hourly Downtime Cost */}
            <div>
              <div className="flex justify-between text-xs font-mono mb-1.5">
                <span className="text-slate-400">Unplanned Downtime Cost / Hour</span>
                <span className="text-amber-400 font-bold">${downtimeCostPerHour.toLocaleString()} / hr</span>
              </div>
              <input
                type="range"
                min="1000"
                max="100000"
                step="1000"
                value={downtimeCostPerHour}
                onChange={(e) => setDowntimeCostPerHour(Number(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            {/* Slider 3: Historical Outage Hours */}
            <div>
              <div className="flex justify-between text-xs font-mono mb-1.5">
                <span className="text-slate-400">Historical Annual Outage Hours</span>
                <span className="text-amber-400 font-bold">{unplannedOutageHoursPerYear} hrs / yr</span>
              </div>
              <input
                type="range"
                min="10"
                max="250"
                value={unplannedOutageHoursPerYear}
                onChange={(e) => setUnplannedOutageHoursPerYear(Number(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            {/* Slider 4: Predictive Lead-Time Effectiveness */}
            <div>
              <div className="flex justify-between text-xs font-mono mb-1.5">
                <span className="text-slate-400">Predictive Prevention Efficacy</span>
                <span className="text-emerald-400 font-bold">{preventedFailureRate}%</span>
              </div>
              <input
                type="range"
                min="40"
                max="95"
                value={preventedFailureRate}
                onChange={(e) => setPreventedFailureRate(Number(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Right Column: Calculated Value Cards (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-[#121927] border border-emerald-900/60 rounded-lg p-5">
              <span className="text-[10px] font-mono uppercase text-slate-400 block mb-1">
                Net Annual Value Generated
              </span>
              <span className="text-3xl font-bold font-mono text-emerald-400 tabular-nums">
                ${totalAnnualSavings.toLocaleString()}
              </span>
              <span className="text-xs text-slate-400 block mt-2">
                Avoided downtime losses and saved emergency expediting fees.
              </span>
            </div>

            <div className="bg-[#121927] border border-amber-900/60 rounded-lg p-5">
              <span className="text-[10px] font-mono uppercase text-slate-400 block mb-1">
                Estimated Capital ROI
              </span>
              <span className="text-3xl font-bold font-mono text-amber-400 tabular-nums">
                {netRoiPercentage}%
              </span>
              <span className="text-xs text-slate-400 block mt-2">
                Payback period reached in <strong className="text-white font-mono">{paybackMonths} months</strong>.
              </span>
            </div>
          </div>

          {/* Sector Proof Metrics */}
          <div className="bg-[#121927] border border-slate-800 rounded-lg p-5">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3 font-mono">
              Sector Reliability Benchmark ({sectorPreset.toUpperCase()})
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
              <div className="p-3 bg-[#0e1422] rounded border border-slate-800">
                <span className="text-slate-500 text-[10px] block">AVOIDED OUTAGES</span>
                <span className="text-white font-bold text-sm">
                  {Math.round(unplannedOutageHoursPerYear * (preventedFailureRate / 100))} hrs/year
                </span>
              </div>
              <div className="p-3 bg-[#0e1422] rounded border border-slate-800">
                <span className="text-slate-500 text-[10px] block">MTBF EXTENSION</span>
                <span className="text-emerald-400 font-bold text-sm">
                  +38.5% Run-Life
                </span>
              </div>
              <div className="p-3 bg-[#0e1422] rounded border border-slate-800">
                <span className="text-slate-500 text-[10px] block">INSURANCE PREMIUM</span>
                <span className="text-amber-400 font-bold text-sm">
                  -14% Risk Credit
                </span>
              </div>
            </div>

            <p className="text-xs text-slate-400 mt-4 leading-relaxed">
              {sectorPreset === 'plants' &&
                'In chemical, polymer, and machining plants, automated ISO 10816 vibration classification eliminates sudden spindle seizures and centrifugal impeller cavitation before product batch contamination occurs.'}
              {sectorPreset === 'utilities' &&
                'In thermal power generation and transmission grid substations, acoustic partial discharge monitoring and bearing pad telemetry avert multimillion-dollar transformer flashovers and forced generation outages.'}
              {sectorPreset === 'fleets' &&
                'In mining haul trucks and commercial line-haul tractors, wheel motor and turbocharger anomaly detection prevents catastrophic highway stalls and high-cost stranded towing.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
