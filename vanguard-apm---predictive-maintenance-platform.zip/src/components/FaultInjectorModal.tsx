import React, { useState } from 'react';
import { Asset } from '../types';
import { Zap, X, ShieldAlert, CheckCircle2, RotateCcw } from 'lucide-react';

interface FaultInjectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  assets: Asset[];
  targetAsset?: Asset | null;
  onInjectFault: (assetId: string, faultType: string) => void;
}

export const FaultInjectorModal: React.FC<FaultInjectorModalProps> = ({
  isOpen,
  onClose,
  assets,
  targetAsset,
  onInjectFault,
}) => {
  const [selectedAssetId, setSelectedAssetId] = useState(targetAsset?.id || assets[0]?.id || '');
  const [selectedFault, setSelectedFault] = useState('bearing_inner_spall');

  if (!isOpen) return null;

  const currentAsset = assets.find((a) => a.id === selectedAssetId) || assets[0];

  const faults = [
    {
      id: 'bearing_inner_spall',
      name: 'Inner Race Bearing Spalling (BPFI Defect)',
      description: 'Increases high-frequency vibration to 8.6 mm/s RMS (ISO Zone D). Spikes acoustic ultrasound & bearing temp.',
      severity: 'critical',
    },
    {
      id: 'rotor_misalignment',
      name: 'Dynamic 2X Angular Coupling Misalignment',
      description: 'Generates strong 2X harmonic energy (7.4 mm/s RMS). Elevates coupling temperature to 82°C.',
      severity: 'critical',
    },
    {
      id: 'cavitation_recirculation',
      name: 'Impeller Suction Cavitation & Shock',
      description: 'Induces rapid suction pressure drop (1.9 bar) and high-frequency broadband acoustic burst (78 dB).',
      severity: 'warning',
    },
    {
      id: 'thermal_lube_breakdown',
      name: 'Lubricant Film Failure & Thermal Runaway',
      description: 'Simulates micro-welding friction: bearing temperature rapidly escalates to 98°C, triggering emergency trip.',
      severity: 'critical',
    },
    {
      id: 'clear_fault',
      name: 'Clear Fault & Restore Nominal Baseline',
      description: 'Resets vibration, temperature, and harmonics back to ISO Zone A nominal benchmark.',
      severity: 'nominal',
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onInjectFault(selectedAssetId, selectedFault);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-[#121927] border border-slate-700 rounded-lg max-w-xl w-full p-6 space-y-5 shadow-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-white">
              Simulate Industrial Anomaly & Fault Injection
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-400 font-medium mb-1 font-mono">
              TARGET ASSET
            </label>
            <select
              value={selectedAssetId}
              onChange={(e) => setSelectedAssetId(e.target.value)}
              className="w-full bg-[#0e1422] border border-slate-700 text-white rounded p-2.5 font-mono focus:outline-none focus:border-amber-500"
            >
              {assets.map((a) => (
                <option key={a.id} value={a.id}>
                  [{a.tag}] {a.name} — Status: {a.status.toUpperCase()} ({a.isoZone})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-slate-400 font-medium mb-2 font-mono">
              SELECT FAILURE SIGNATURE TO INJECT
            </label>
            <div className="space-y-2">
              {faults.map((f) => {
                const isSelected = selectedFault === f.id;
                const isReset = f.id === 'clear_fault';

                return (
                  <label
                    key={f.id}
                    className={`block p-3 rounded border cursor-pointer transition-all ${
                      isSelected
                        ? isReset
                          ? 'bg-emerald-950/30 border-emerald-500'
                          : 'bg-amber-950/30 border-amber-500'
                        : 'bg-[#0e1422] border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <input
                          type="radio"
                          name="faultType"
                          value={f.id}
                          checked={isSelected}
                          onChange={(e) => setSelectedFault(e.target.value)}
                          className="accent-amber-500"
                        />
                        <span className="font-semibold text-white">{f.name}</span>
                      </div>
                      <span
                        className={`text-[10px] font-mono uppercase px-1.5 py-0.5 rounded font-bold ${
                          f.severity === 'critical'
                            ? 'text-rose-400'
                            : f.severity === 'warning'
                            ? 'text-amber-400'
                            : 'text-emerald-400'
                        }`}
                      >
                        {f.severity}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1 pl-6">
                      {f.description}
                    </p>
                  </label>
                );
              })}
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold rounded text-xs transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              <Zap className="w-3.5 h-3.5 text-slate-950" />
              <span>Apply Simulation to {currentAsset.tag}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
