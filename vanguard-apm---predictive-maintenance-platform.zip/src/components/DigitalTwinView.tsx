import React, { useState, useEffect } from 'react';
import { Asset, SensorPoint, TelemetryHistoryPoint } from '../types';
import { generateInitialHistory } from '../utils/telemetryEngine';
import { Activity, Radio, Cpu, AlertTriangle, Play, Sparkles } from 'lucide-react';

interface DigitalTwinViewProps {
  asset: Asset;
  assets: Asset[];
  onSelectAsset: (asset: Asset) => void;
  onNavigateToAnomaliesForAsset: (asset: Asset) => void;
  isStreaming: boolean;
}

export const DigitalTwinView: React.FC<DigitalTwinViewProps> = ({
  asset,
  assets,
  onSelectAsset,
  onNavigateToAnomaliesForAsset,
  isStreaming,
}) => {
  const [selectedSensor, setSelectedSensor] = useState<SensorPoint | null>(asset.sensorPoints[0] || null);
  const [history, setHistory] = useState<TelemetryHistoryPoint[]>([]);

  // Initialize and append to history as streaming progresses
  useEffect(() => {
    setHistory(generateInitialHistory(asset, 24));
  }, [asset.id]);

  useEffect(() => {
    if (!isStreaming) return;
    const interval = setInterval(() => {
      setHistory((prev) => {
        const nextTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        const newPoint: TelemetryHistoryPoint = {
          timestamp: nextTime,
          vibrationRms: asset.telemetry.vibrationRms,
          bearingTemp: asset.telemetry.bearingTemp,
          acousticUltrasound: asset.telemetry.acousticUltrasound,
          oilPressure: asset.telemetry.oilPressure,
          anomalyScore: asset.status === 'critical' ? 84 : asset.status === 'warning' ? 52 : 14,
        };
        return [...prev.slice(1), newPoint];
      });
    }, 2000);

    return () => clearInterval(interval);
  }, [isStreaming, asset]);

  // Keep selected sensor updated if asset sensor points change
  useEffect(() => {
    if (selectedSensor) {
      const match = asset.sensorPoints.find((s) => s.id === selectedSensor.id);
      if (match) setSelectedSensor(match);
      else setSelectedSensor(asset.sensorPoints[0] || null);
    } else {
      setSelectedSensor(asset.sensorPoints[0] || null);
    }
  }, [asset]);

  // Render SVG digital twin based on asset sector/type
  const renderTwinSchematic = () => {
    const isPump = asset.type.toLowerCase().includes('pump');
    const isTurbine = asset.type.toLowerCase().includes('turbine');
    const isTransformer = asset.type.toLowerCase().includes('transformer');

    return (
      <div className="relative w-full aspect-[16/9] bg-[#0d121c] rounded-lg border border-slate-800 overflow-hidden flex items-center justify-center p-6">
        {/* Engineering grid backdrop */}
        <div
          className="absolute inset-0 opacity-15 pointer-events-none"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, #94a3b8 1px, transparent 0)`,
            backgroundSize: '24px 24px',
          }}
        />

        {/* Center schematic illustration in SVG */}
        <svg viewBox="0 0 800 450" className="w-full h-full max-h-[380px] drop-shadow-md">
          <defs>
            <linearGradient id="metalGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#1e293b" />
              <stop offset="50%" stopColor="#334155" />
              <stop offset="100%" stopColor="#0f172a" />
            </linearGradient>
            <linearGradient id="accentGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#f59e0b" stopOpacity="0.05" />
            </linearGradient>
          </defs>

          {isPump ? (
            /* Centrifugal Pump Schematic */
            <g id="pump-assembly">
              {/* Base plate */}
              <rect x="80" y="320" width="640" height="24" rx="4" fill="#1e293b" stroke="#475569" strokeWidth="2" />
              {/* Electric Motor Housing */}
              <rect x="120" y="160" width="220" height="150" rx="8" fill="url(#metalGrad)" stroke="#64748b" strokeWidth="2" />
              {/* Motor cooling fins */}
              <line x1="140" y1="160" x2="140" y2="310" stroke="#475569" strokeWidth="2" />
              <line x1="170" y1="160" x2="170" y2="310" stroke="#475569" strokeWidth="2" />
              <line x1="200" y1="160" x2="200" y2="310" stroke="#475569" strokeWidth="2" />
              <line x1="230" y1="160" x2="230" y2="310" stroke="#475569" strokeWidth="2" />
              <line x1="260" y1="160" x2="260" y2="310" stroke="#475569" strokeWidth="2" />
              <line x1="290" y1="160" x2="290" y2="310" stroke="#475569" strokeWidth="2" />
              {/* Coupling Shroud */}
              <rect x="340" y="210" width="60" height="50" rx="4" fill="#334155" stroke="#f59e0b" strokeWidth="1.5" />
              {/* Rotating shaft line */}
              <line x1="330" y1="235" x2="480" y2="235" stroke="#cbd5e1" strokeWidth="6" strokeDasharray={isStreaming ? '6 4' : 'none'} />
              {/* Bearing housing */}
              <rect x="400" y="190" width="100" height="90" rx="6" fill="#1e293b" stroke="#94a3b8" strokeWidth="2" />
              <circle cx="450" cy="235" r="28" fill="#0f172a" stroke="#f59e0b" strokeWidth="2" />
              {/* Volute / Pump Casing */}
              <path d="M 500 235 C 500 150, 620 140, 680 190 C 720 220, 720 290, 660 310 C 600 330, 500 310, 500 235 Z" fill="url(#metalGrad)" stroke="#64748b" strokeWidth="2" />
              {/* Discharge nozzle */}
              <rect x="620" y="90" width="60" height="90" rx="3" fill="#1e293b" stroke="#64748b" strokeWidth="2" />
              {/* Suction flange */}
              <path d="M 680 215 L 750 215 L 750 265 L 680 265 Z" fill="#334155" stroke="#64748b" strokeWidth="2" />
            </g>
          ) : isTurbine ? (
            /* Gas Turbine Assembly */
            <g id="turbine-assembly">
              <rect x="60" y="330" width="680" height="20" rx="3" fill="#1e293b" stroke="#475569" strokeWidth="2" />
              {/* Compressor section */}
              <polygon points="100,280 260,250 260,190 100,160" fill="url(#metalGrad)" stroke="#64748b" strokeWidth="2" />
              {/* Combustor ring */}
              <rect x="270" y="170" width="120" height="100" rx="6" fill="#334155" stroke="#f59e0b" strokeWidth="2" />
              {/* Dynamic flame / acoustic zone */}
              <circle cx="330" cy="220" r="30" fill="url(#accentGrad)" />
              {/* Turbine expansion stages */}
              <polygon points="400,200 620,150 620,290 400,240" fill="url(#metalGrad)" stroke="#64748b" strokeWidth="2" />
              {/* Generator bell housing */}
              <rect x="630" y="170" width="110" height="100" rx="4" fill="#1e293b" stroke="#475569" strokeWidth="2" />
              {/* Central rotor shaft */}
              <line x1="80" y1="220" x2="720" y2="220" stroke="#f8fafc" strokeWidth="4" strokeDasharray={isStreaming ? '8 4' : 'none'} />
            </g>
          ) : isTransformer ? (
            /* Substation Transformer */
            <g id="transformer-assembly">
              <rect x="200" y="160" width="400" height="200" rx="8" fill="url(#metalGrad)" stroke="#64748b" strokeWidth="2" />
              {/* Cooling Radiator Banks */}
              <rect x="120" y="180" width="60" height="160" fill="#1e293b" stroke="#475569" strokeWidth="1.5" />
              <rect x="620" y="180" width="60" height="160" fill="#1e293b" stroke="#475569" strokeWidth="1.5" />
              {/* Conservator tank */}
              <rect x="320" y="90" width="160" height="50" rx="10" fill="#334155" stroke="#94a3b8" strokeWidth="2" />
              {/* HV Bushings */}
              <polygon points="260,160 250,70 270,70 280,160" fill="#475569" stroke="#cbd5e1" strokeWidth="1.5" />
              <polygon points="390,160 380,70 400,70 410,160" fill="#475569" stroke="#cbd5e1" strokeWidth="1.5" />
              <polygon points="520,160 510,70 530,70 540,160" fill="#475569" stroke="#cbd5e1" strokeWidth="1.5" />
            </g>
          ) : (
            /* Heavy Haul / Fleet Engine Powertrain */
            <g id="fleet-powertrain">
              <rect x="80" y="320" width="640" height="20" rx="4" fill="#1e293b" stroke="#475569" strokeWidth="2" />
              {/* Engine Block */}
              <rect x="140" y="160" width="280" height="150" rx="6" fill="url(#metalGrad)" stroke="#64748b" strokeWidth="2" />
              {/* Turbocharger Assembly */}
              <circle cx="480" cy="180" r="45" fill="#334155" stroke="#f59e0b" strokeWidth="2" />
              <circle cx="480" cy="180" r="22" fill="#0f172a" stroke="#f59e0b" strokeWidth="1.5" />
              {/* Final Drive Wheel Hub */}
              <circle cx="620" cy="270" r="60" fill="url(#metalGrad)" stroke="#94a3b8" strokeWidth="3" />
              <circle cx="620" cy="270" r="30" fill="#0f172a" stroke="#cbd5e1" strokeWidth="2" />
              {/* Planetary drive studs */}
              <circle cx="620" cy="250" r="4" fill="#f59e0b" />
              <circle cx="638" cy="265" r="4" fill="#f59e0b" />
              <circle cx="630" cy="285" r="4" fill="#f59e0b" />
              <circle cx="610" cy="285" r="4" fill="#f59e0b" />
              <circle cx="602" cy="265" r="4" fill="#f59e0b" />
            </g>
          )}

          {/* Render Clickable IoT Sensor Node Pins */}
          {asset.sensorPoints.map((sensor) => {
            const isSelected = selectedSensor?.id === sensor.id;
            const px = (sensor.x / 100) * 800;
            const py = (sensor.y / 100) * 450;

            const isCritical = sensor.status === 'critical';
            const isWarning = sensor.status === 'warning';
            const pinColor = isCritical ? '#f43f5e' : isWarning ? '#f59e0b' : '#10b981';

            return (
              <g
                key={sensor.id}
                className="cursor-pointer transition-transform hover:scale-110"
                onClick={() => setSelectedSensor(sensor)}
              >
                {/* Pulse ring if anomalous */}
                {(isCritical || isWarning) && (
                  <circle
                    cx={px}
                    cy={py}
                    r={isSelected ? '22' : '16'}
                    fill="none"
                    stroke={pinColor}
                    strokeWidth="1.5"
                    opacity="0.6"
                    className="animate-ping"
                  />
                )}
                {/* Outer ring */}
                <circle
                  cx={px}
                  cy={py}
                  r={isSelected ? '14' : '10'}
                  fill="#0b0f17"
                  stroke={pinColor}
                  strokeWidth={isSelected ? '3' : '2'}
                />
                {/* Center dot */}
                <circle cx={px} cy={py} r="4" fill={pinColor} />
                {/* Sensor label pill */}
                <rect
                  x={px - 45}
                  y={py - 30}
                  width="90"
                  height="18"
                  rx="3"
                  fill="#0f172a"
                  stroke={isSelected ? pinColor : '#334155'}
                  strokeWidth="1"
                />
                <text
                  x={px}
                  y={py - 18}
                  fill="#e2e8f0"
                  fontSize="9"
                  fontFamily="JetBrains Mono"
                  textAnchor="middle"
                  fontWeight="600"
                >
                  {sensor.value} {sensor.unit.split(' ')[0]}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Legend Overlay at bottom */}
        <div className="absolute bottom-3 left-4 flex items-center gap-3 text-[11px] font-mono bg-slate-950/80 backdrop-blur px-3 py-1.5 rounded border border-slate-800">
          <span className="text-slate-400">Telemetry Probes:</span>
          <span className="flex items-center gap-1 text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" /> Nominal
          </span>
          <span className="flex items-center gap-1 text-amber-400">
            <span className="w-2 h-2 rounded-full bg-amber-500 inline-block" /> Warning (Zone C)
          </span>
          <span className="flex items-center gap-1 text-rose-400 font-semibold">
            <span className="w-2 h-2 rounded-full bg-rose-500 inline-block" /> Critical (Zone D)
          </span>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Asset Selector & Header Info */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-[#121927] border border-slate-800 rounded-lg p-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="font-mono text-xs font-bold text-amber-400 tracking-wider">
              {asset.tag}
            </span>
            <span className="text-slate-600 text-xs">·</span>
            <span className="text-xs text-slate-400 capitalize">{asset.sector}</span>
            <span className="text-slate-600 text-xs">·</span>
            <span className="text-xs text-slate-400">{asset.facility}</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight">{asset.name}</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Operating Hours: <span className="font-mono text-slate-200">{asset.operatingHours.toLocaleString()} hrs</span> · 
            RUL Estimate: <span className="font-mono text-amber-400 font-semibold">{asset.rulHours} hrs</span> · 
            ISO 10816 Status: <span className="font-mono font-semibold text-rose-400">{asset.isoZone}</span>
          </p>
        </div>

        {/* Quick Asset Switcher Dropdown */}
        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <span className="text-[11px] text-slate-400 block">Switch Digital Twin</span>
            <select
              value={asset.id}
              onChange={(e) => {
                const found = assets.find((a) => a.id === e.target.value);
                if (found) onSelectAsset(found);
              }}
              className="bg-[#0e1422] border border-slate-700 text-xs text-white rounded px-2.5 py-1.5 focus:outline-none focus:border-amber-500 font-mono"
            >
              {assets.map((a) => (
                <option key={a.id} value={a.id}>
                  [{a.tag}] {a.name.slice(0, 32)}...
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => onNavigateToAnomaliesForAsset(asset)}
            className="px-3.5 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Anomaly Diagnostic</span>
          </button>
        </div>
      </div>

      {/* Main Digital Twin Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Schematic + Selected Sensor HUD */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-[#121927] border border-slate-800 rounded-lg p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Cpu className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-semibold text-white">
                  Interactive Machine Schematic & IoT Probe Array
                </h3>
              </div>
              <span className="text-xs font-mono text-slate-400">
                {asset.sensorPoints.length} active high-frequency probes
              </span>
            </div>

            {renderTwinSchematic()}

            {/* Selected Sensor Detailed Inspector Card */}
            {selectedSensor && (
              <div className="mt-4 p-4 rounded-lg bg-[#0e1422] border border-slate-800">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Radio className="w-4 h-4 text-amber-400" />
                    <span className="text-sm font-semibold text-white font-mono">
                      {selectedSensor.name}
                    </span>
                    <span
                      className={`text-xs font-mono font-semibold uppercase px-2 py-0.5 rounded ${
                        selectedSensor.status === 'critical'
                          ? 'bg-rose-950/60 text-rose-300 border border-rose-800/80'
                          : selectedSensor.status === 'warning'
                          ? 'bg-amber-950/60 text-amber-300 border border-amber-800/80'
                          : 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/80'
                      }`}
                    >
                      {selectedSensor.status}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-lg font-bold font-mono text-white tabular-nums">
                      {selectedSensor.value} {selectedSensor.unit}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3 mt-3 pt-3 border-t border-slate-800/80 text-xs font-mono">
                  <div>
                    <span className="text-slate-500 text-[10px] block">NOMINAL RANGE</span>
                    <span className="text-slate-300">
                      {selectedSensor.nominalRange[0]} - {selectedSensor.nominalRange[1]} {selectedSensor.unit}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 text-[10px] block">SENSOR TRANSDUCER</span>
                    <span className="text-slate-300">
                      {selectedSensor.type === 'vibration'
                        ? 'Piezoelectric Accelerometer 100 mV/g'
                        : selectedSensor.type === 'temperature'
                        ? 'Pt100 RTD Class A 4-Wire'
                        : selectedSensor.type === 'acoustic'
                        ? 'Ultrasonic Acoustic Emission (30kHz)'
                        : 'Piezo-Resistive Pressure Transducer'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 text-[10px] block">INGESTION PROTOCOL</span>
                    <span className="text-emerald-400">MQTT Sparkplug B (24-bit ADC)</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Time Series Telemetry History Strip Chart */}
          <div className="bg-[#121927] border border-slate-800 rounded-lg p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-semibold text-white">
                  Real-Time High-Frequency Vibration Velocity (mm/s RMS)
                </h3>
              </div>
              <span className="text-xs font-mono text-slate-400">
                Sampling Rate: 1000 Hz · Ingestion Buffer: 30s
              </span>
            </div>

            {/* SVG Line Chart */}
            <div className="h-44 w-full relative">
              <svg viewBox="0 0 600 160" className="w-full h-full">
                {/* Horizontal reference bands (ISO 10816 Zones) */}
                <rect x="0" y="0" width="600" height="40" fill="rgba(244,63,94,0.06)" />
                <line x1="0" y1="40" x2="600" y2="40" stroke="#f43f5e" strokeDasharray="3 3" strokeWidth="0.8" />
                <text x="6" y="34" fill="#f43f5e" fontSize="9" fontFamily="JetBrains Mono">
                  ISO Zone D Trip Threshold (7.1 mm/s)
                </text>

                <rect x="0" y="40" width="600" height="50" fill="rgba(245,158,11,0.04)" />
                <line x1="0" y1="90" x2="600" y2="90" stroke="#f59e0b" strokeDasharray="3 3" strokeWidth="0.8" />
                <text x="6" y="84" fill="#f59e0b" fontSize="9" fontFamily="JetBrains Mono">
                  ISO Zone C Warning Threshold (4.5 mm/s)
                </text>

                {/* Vibration line path */}
                {history.length > 1 && (
                  <path
                    d={history.reduce((acc, point, index) => {
                      const x = (index / (history.length - 1)) * 580 + 10;
                      // scale 0 to 10 mm/s to 150 to 10 y
                      const y = Math.max(10, Math.min(150, 150 - (point.vibrationRms / 10) * 140));
                      return `${acc} ${index === 0 ? 'M' : 'L'} ${x} ${y}`;
                    }, '')}
                    fill="none"
                    stroke={asset.status === 'critical' ? '#f43f5e' : asset.status === 'warning' ? '#f59e0b' : '#10b981'}
                    strokeWidth="2.5"
                  />
                )}

                {/* History data points */}
                {history.map((point, index) => {
                  const x = (index / (history.length - 1)) * 580 + 10;
                  const y = Math.max(10, Math.min(150, 150 - (point.vibrationRms / 10) * 140));
                  return (
                    <circle
                      key={index}
                      cx={x}
                      cy={y}
                      r="2.5"
                      fill={asset.status === 'critical' ? '#f43f5e' : '#10b981'}
                    />
                  );
                })}
              </svg>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono pt-2 border-t border-slate-800">
              <span>{history[0]?.timestamp || '00:00:00'}</span>
              <span>LIVE TELEMETRY WINDOW (30s)</span>
              <span>{history[history.length - 1]?.timestamp || '00:00:00'}</span>
            </div>
          </div>
        </div>

        {/* Right Col: Spectral FFT Harmonics & Live Oscilloscope */}
        <div className="space-y-4">
          {/* Fast Fourier Transform (FFT) Harmonic Spectrum */}
          <div className="bg-[#121927] border border-slate-800 rounded-lg p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-semibold text-white">
                  FFT Harmonic Spectrum
                </h3>
              </div>
              <span className="text-[11px] font-mono text-slate-400">Demodulated Peaks</span>
            </div>

            <p className="text-xs text-slate-400 mb-4">
              Identifies mechanical root cause through harmonic multiples and bearing fault signatures.
            </p>

            <div className="space-y-3 font-mono text-xs">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-slate-300">1X Rotational Speed (Unbalance)</span>
                  <span className="text-slate-200 tabular-nums">{asset.harmonics.runningSpeed1X} mm/s</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded overflow-hidden">
                  <div
                    style={{ width: `${Math.min(100, (asset.harmonics.runningSpeed1X / 10) * 100)}%` }}
                    className="bg-emerald-500 h-full"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-slate-300">2X Angular Misalignment</span>
                  <span className={`tabular-nums ${asset.harmonics.misalignment2X > 4.0 ? 'text-rose-400 font-bold' : 'text-slate-200'}`}>
                    {asset.harmonics.misalignment2X} mm/s
                  </span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded overflow-hidden">
                  <div
                    style={{ width: `${Math.min(100, (asset.harmonics.misalignment2X / 10) * 100)}%` }}
                    className={`h-full ${asset.harmonics.misalignment2X > 4.0 ? 'bg-rose-500' : 'bg-amber-500'}`}
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-slate-300">BPFI (Inner Race Bearing Pass)</span>
                  <span className={`tabular-nums ${asset.harmonics.bearingPassInnerBPFI > 4.0 ? 'text-rose-400 font-bold' : 'text-slate-200'}`}>
                    {asset.harmonics.bearingPassInnerBPFI} mm/s
                  </span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded overflow-hidden">
                  <div
                    style={{ width: `${Math.min(100, (asset.harmonics.bearingPassInnerBPFI / 10) * 100)}%` }}
                    className={`h-full ${asset.harmonics.bearingPassInnerBPFI > 4.0 ? 'bg-rose-500' : 'bg-emerald-500'}`}
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-slate-300">GMF (Gear Mesh Frequency)</span>
                  <span className="text-slate-200 tabular-nums">{asset.harmonics.gearMeshFrequencyGMF} mm/s</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded overflow-hidden">
                  <div
                    style={{ width: `${Math.min(100, (asset.harmonics.gearMeshFrequencyGMF / 10) * 100)}%` }}
                    className="bg-sky-500 h-full"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Real-Time Waveform Oscilloscope Simulation */}
          <div className="bg-[#121927] border border-slate-800 rounded-lg p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-white">
                Live Waveform Oscilloscope
              </h3>
              <span className="text-[11px] font-mono text-emerald-400">16-Bit Sync</span>
            </div>

            <div className="w-full h-32 bg-[#090d15] rounded border border-slate-800 p-2 flex items-center justify-center relative overflow-hidden">
              {/* Oscilloscope reticle grid */}
              <div
                className="absolute inset-0 opacity-20 pointer-events-none"
                style={{
                  backgroundImage: `linear-gradient(#38bdf8 1px, transparent 1px), linear-gradient(90deg, #38bdf8 1px, transparent 1px)`,
                  backgroundSize: '20px 20px',
                }}
              />

              <svg viewBox="0 0 300 100" className="w-full h-full relative z-10">
                <path
                  d={Array.from({ length: 60 }).reduce<string>((acc, _, i) => {
                    const x = (i / 59) * 300;
                    // Sinusoidal wave with distortion if anomalous
                    const isSevere = asset.status !== 'nominal';
                    const phase = Date.now() / 150;
                    const amp = isSevere ? 34 : 18;
                    const distortion = isSevere ? Math.sin((i + phase) * 0.8) * 12 : 0;
                    const y = 50 + Math.sin(i * 0.4 + phase) * amp + distortion;
                    return `${acc} ${i === 0 ? 'M' : 'L'} ${x} ${y}`;
                  }, '')}
                  fill="none"
                  stroke={asset.status === 'critical' ? '#f43f5e' : '#38bdf8'}
                  strokeWidth="2"
                />
              </svg>
            </div>

            <div className="mt-3 flex items-center justify-between text-xs font-mono text-slate-400">
              <span>Timebase: 5 ms/div</span>
              <span>Sens: 2.0 mV/div</span>
              <span className="text-slate-200">Sampling: 48 kHz</span>
            </div>
          </div>

          {/* Machine Health Specifications */}
          <div className="bg-[#121927] border border-slate-800 rounded-lg p-5">
            <h3 className="text-sm font-semibold text-white mb-3">
              Reliability Baseline & CMMS Tag
            </h3>
            <div className="space-y-2 text-xs font-mono">
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-500">TAG NO.</span>
                <span className="text-amber-400 font-semibold">{asset.tag}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-500">CRITICALITY</span>
                <span className="text-rose-400 font-semibold">{asset.criticality}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-500">INSTALLED LOCATION</span>
                <span className="text-slate-300">{asset.location}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-500">LAST OVERHAUL</span>
                <span className="text-slate-300">{asset.lastMaintainedDate}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">RATED RPM</span>
                <span className="text-slate-300">{asset.telemetry.rpm.toLocaleString()} RPM</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
