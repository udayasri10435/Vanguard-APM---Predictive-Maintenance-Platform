import React, { useState } from 'react';
import { WorkOrder, Asset, Priority } from '../types';
import { exportWorkOrderToCmms } from '../utils/telemetryEngine';
import { Wrench, Clock, CheckCircle2, Copy, FileText, Download, Plus, AlertCircle, X } from 'lucide-react';

interface WorkOrdersViewProps {
  workOrders: WorkOrder[];
  assets: Asset[];
  onUpdateWorkOrderStatus: (id: string, newStatus: WorkOrder['status']) => void;
  onCreateWorkOrder: (wo: WorkOrder) => void;
}

export const WorkOrdersView: React.FC<WorkOrdersViewProps> = ({
  workOrders,
  assets,
  onUpdateWorkOrderStatus,
  onCreateWorkOrder,
}) => {
  const [selectedWorkOrder, setSelectedWorkOrder] = useState<WorkOrder | null>(workOrders[0] || null);
  const [statusFilter, setStatusFilter] = useState<'all' | 'draft' | 'dispatched' | 'in_progress' | 'completed'>('all');
  const [cmmsExportModalOpen, setCmmsExportModalOpen] = useState(false);
  const [exportFormat, setExportFormat] = useState<'sap' | 'maximo' | 'json'>('sap');
  const [copySuccess, setCopySuccess] = useState(false);

  // New Work Order Modal
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [newAssetId, setNewAssetId] = useState(assets[0]?.id || '');
  const [newTitle, setNewTitle] = useState('');
  const [newPriority, setNewPriority] = useState<Priority>('P2_HIGH');
  const [newTech, setNewTech] = useState('Sarah Jenkins (Lead Mech Tech)');
  const [newDowntimeHours, setNewDowntimeHours] = useState('2.5');

  const filteredOrders = workOrders.filter((wo) => {
    if (statusFilter === 'all') return true;
    return wo.status === statusFilter;
  });

  const handleCopyCmms = () => {
    if (!selectedWorkOrder) return;
    const text = exportWorkOrderToCmms(selectedWorkOrder, exportFormat);
    navigator.clipboard.writeText(text);
    setCopySuccess(true);
    setTimeout(() => setCopySuccess(false), 2000);
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const assetObj = assets.find((a) => a.id === newAssetId) || assets[0];
    const newWo: WorkOrder = {
      id: `WO-${Math.floor(1000 + Math.random() * 9000)}`,
      assetId: assetObj.id,
      assetName: assetObj.name,
      assetTag: assetObj.tag,
      sector: assetObj.sector,
      title: newTitle || `Preventive Inspection for ${assetObj.tag}`,
      priority: newPriority,
      status: 'draft',
      createdAt: 'Today, Just now',
      dueInHours: newPriority === 'P1_CRITICAL' ? 8 : 48,
      assignedTechnician: newTech,
      technicianRole: 'Rotating Equipment Specialist',
      technicianCert: 'ISO Condition Monitoring Certified',
      estimatedDowntimeHours: parseFloat(newDowntimeHours) || 2.5,
      estimatedSavingsUSD: newPriority === 'P1_CRITICAL' ? 35000 : 15000,
      rootCauseSummary: 'Operator initiated maintenance ticket based on telemetry drift trend.',
      isoStandardProcedure: 'ISO 10816 Standard Operational Maintenance Protocol',
      steps: [
        'Perform machine lock-out / tag-out safety checklist.',
        'Visual and thermographic inspection of coupling and bearing housing.',
        'Flush grease reservoir and repack with fresh synthetic lubricant.',
        'Execute baseline vibration check post-service.',
      ],
      partsRequired: [
        { partNumber: 'OEM-SEAL-KIT-1', description: 'Elastomer Gasket & Viton Seal Replacement Kit', qty: 1, inStock: true, unitCostUSD: 180 },
        { partNumber: 'SYN-LUBE-460', description: 'Synthetic Polyurea Lubricant (400g Cartridge)', qty: 2, inStock: true, unitCostUSD: 45 },
      ],
    };

    onCreateWorkOrder(newWo);
    setSelectedWorkOrder(newWo);
    setCreateModalOpen(false);
    setNewTitle('');
  };

  return (
    <div className="space-y-6">
      {/* Header strip */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#121927] border border-slate-800 rounded-lg p-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Wrench className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-semibold uppercase tracking-wider text-amber-400">
              Work Order Automation & Dispatch Engine
            </span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            Automated Field Dispatch & CMMS Integration
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Auto-synthesizes step-by-step repair tasks, certified technician assignments, and BOM parts lists
            the instant an IoT anomaly triggers. Fully exportable to SAP PM and IBM Maximo.
          </p>
        </div>

        <button
          onClick={() => setCreateModalOpen(true)}
          className="px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold rounded text-xs transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Work Order</span>
        </button>
      </div>

      {/* Main Grid: Work Order List (Left) + Detail View (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Work Order Table & Filter (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#121927] border border-slate-800 rounded-lg p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-white">
                Work Orders Queue ({filteredOrders.length})
              </h3>

              {/* Status Segmented Filter */}
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="bg-[#0e1422] border border-slate-700 text-xs text-slate-200 rounded px-2 py-1 font-mono focus:outline-none focus:border-amber-500"
              >
                <option value="all">All Statuses</option>
                <option value="draft">Draft</option>
                <option value="dispatched">Dispatched</option>
                <option value="in_progress">In Progress</option>
                <option value="completed">Completed</option>
              </select>
            </div>

            <div className="space-y-3">
              {filteredOrders.map((wo) => {
                const isSelected = selectedWorkOrder?.id === wo.id;
                const isP1 = wo.priority === 'P1_CRITICAL';

                return (
                  <div
                    key={wo.id}
                    onClick={() => setSelectedWorkOrder(wo)}
                    className={`p-3.5 rounded-lg border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-amber-950/20 border-amber-500/80 shadow-[0_0_12px_rgba(245,158,11,0.08)]'
                        : 'bg-[#0e1422] border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2 mb-1.5">
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono text-xs font-bold text-amber-400">
                          {wo.id}
                        </span>
                        <span className="text-slate-600 text-xs">·</span>
                        <span className="text-xs text-slate-400 font-mono">
                          {wo.assetTag}
                        </span>
                      </div>
                      <span
                        className={`text-[10px] font-mono font-bold uppercase px-1.5 py-0.5 rounded ${
                          wo.status === 'completed'
                            ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800'
                            : wo.status === 'in_progress'
                            ? 'bg-sky-950/60 text-sky-300 border border-sky-800'
                            : wo.status === 'dispatched'
                            ? 'bg-amber-950/60 text-amber-300 border border-amber-800'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {wo.status.replace('_', ' ')}
                      </span>
                    </div>

                    <h4 className="text-xs font-semibold text-white line-clamp-1">
                      {wo.title}
                    </h4>

                    <div className="mt-2 flex items-center justify-between text-[11px] font-mono text-slate-400">
                      <span>Tech: <strong className="text-slate-200">{wo.assignedTechnician}</strong></span>
                      <span className={isP1 ? 'text-rose-400 font-bold' : 'text-slate-300'}>
                        {wo.priority}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Detailed Selected Work Order Drawer (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          {selectedWorkOrder ? (
            <div className="bg-[#121927] border border-slate-800 rounded-lg p-5 space-y-5">
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-4 border-b border-slate-800">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-mono text-xs font-bold text-amber-400">
                      {selectedWorkOrder.id}
                    </span>
                    <span className="text-slate-600 text-xs">·</span>
                    <span className="text-xs text-slate-400 font-mono">{selectedWorkOrder.assetTag}</span>
                    <span className="text-slate-600 text-xs">·</span>
                    <span className="text-xs text-slate-400">{selectedWorkOrder.assetName}</span>
                  </div>
                  <h3 className="text-base font-bold text-white tracking-tight">
                    {selectedWorkOrder.title}
                  </h3>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setCmmsExportModalOpen(true)}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5 text-amber-400" />
                    <span>Sync CMMS</span>
                  </button>
                </div>
              </div>

              {/* Status and Action Buttons */}
              <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-[#0e1422] rounded-lg border border-slate-800">
                <div className="flex items-center gap-2 text-xs font-mono">
                  <span className="text-slate-500 uppercase text-[10px]">CURRENT STAGE:</span>
                  <span className="text-amber-400 font-bold uppercase">{selectedWorkOrder.status.replace('_', ' ')}</span>
                  <span className="text-slate-600">·</span>
                  <span className="text-slate-400">SLA Due in <strong className="text-white">{selectedWorkOrder.dueInHours}h</strong></span>
                </div>

                {/* State Transition Action Buttons */}
                <div className="flex items-center gap-2">
                  {selectedWorkOrder.status === 'draft' && (
                    <button
                      onClick={() => onUpdateWorkOrderStatus(selectedWorkOrder.id, 'dispatched')}
                      className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold rounded text-xs transition-colors cursor-pointer"
                    >
                      Dispatch Field Crew
                    </button>
                  )}
                  {selectedWorkOrder.status === 'dispatched' && (
                    <button
                      onClick={() => onUpdateWorkOrderStatus(selectedWorkOrder.id, 'in_progress')}
                      className="px-3 py-1 bg-sky-600 hover:bg-sky-500 text-white font-semibold rounded text-xs transition-colors cursor-pointer"
                    >
                      Mark In Progress
                    </button>
                  )}
                  {selectedWorkOrder.status === 'in_progress' && (
                    <button
                      onClick={() => onUpdateWorkOrderStatus(selectedWorkOrder.id, 'completed')}
                      className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded text-xs transition-colors cursor-pointer"
                    >
                      Sign-Off & Close
                    </button>
                  )}
                  {selectedWorkOrder.status === 'completed' && (
                    <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Maintenance Verified
                    </span>
                  )}
                </div>
              </div>

              {/* Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
                <div className="p-3 bg-[#0e1422] rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">EST. DOWNTIME</span>
                  <span className="text-white font-bold text-sm tabular-nums">
                    {selectedWorkOrder.estimatedDowntimeHours} hrs
                  </span>
                </div>
                <div className="p-3 bg-[#0e1422] rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">AVOIDED LOSS</span>
                  <span className="text-emerald-400 font-bold text-sm tabular-nums">
                    ${selectedWorkOrder.estimatedSavingsUSD.toLocaleString()}
                  </span>
                </div>
                <div className="p-3 bg-[#0e1422] rounded border border-slate-800 col-span-2">
                  <span className="text-slate-500 text-[10px] block">ASSIGNED TECHNICIAN</span>
                  <span className="text-white font-bold text-xs">
                    {selectedWorkOrder.assignedTechnician}
                  </span>
                  <span className="text-slate-400 text-[10px] block mt-0.5">
                    {selectedWorkOrder.technicianCert}
                  </span>
                </div>
              </div>

              {/* Root Cause Summary */}
              <div className="p-4 rounded bg-[#0e1422] border border-slate-800 text-xs">
                <span className="text-amber-400 font-semibold font-mono uppercase tracking-wider block mb-1">
                  Root Cause Diagnostics
                </span>
                <p className="text-slate-300 leading-relaxed">
                  {selectedWorkOrder.rootCauseSummary}
                </p>
              </div>

              {/* Execution Steps */}
              <div className="p-4 rounded bg-[#0e1422] border border-slate-800">
                <span className="text-slate-400 font-semibold font-mono text-xs uppercase tracking-wider block mb-2">
                  Standard Operating Protocol ({selectedWorkOrder.isoStandardProcedure})
                </span>
                <ol className="space-y-2 text-xs text-slate-300">
                  {selectedWorkOrder.steps.map((step, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-amber-400 font-mono font-bold">{idx + 1}.</span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ol>
              </div>

              {/* Parts & Bill of Materials */}
              <div className="p-4 rounded bg-[#0e1422] border border-slate-800">
                <span className="text-slate-400 font-semibold font-mono text-xs uppercase tracking-wider block mb-3">
                  Bill of Materials (BOM) & Inventory Status
                </span>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs font-mono text-left">
                    <thead>
                      <tr className="text-slate-500 border-b border-slate-800 text-[10px]">
                        <th className="pb-2">PART NUMBER</th>
                        <th className="pb-2">DESCRIPTION</th>
                        <th className="pb-2 text-right">QTY</th>
                        <th className="pb-2 text-right">IN STOCK</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {selectedWorkOrder.partsRequired.map((part, idx) => (
                        <tr key={idx} className="text-slate-300">
                          <td className="py-2 text-amber-400 font-bold">{part.partNumber}</td>
                          <td className="py-2 text-slate-300">{part.description}</td>
                          <td className="py-2 text-right tabular-nums">{part.qty}</td>
                          <td className="py-2 text-right">
                            <span
                              className={`px-1.5 py-0.5 rounded text-[10px] ${
                                part.inStock
                                  ? 'bg-emerald-950 text-emerald-300'
                                  : 'bg-rose-950 text-rose-300'
                              }`}
                            >
                              {part.inStock ? 'YES' : 'BACKORDER'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-[#121927] border border-slate-800 rounded-lg p-12 text-center text-slate-400">
              <FileText className="w-8 h-8 mx-auto text-slate-600 mb-2" />
              <p className="text-sm">Select a work order from the list to view task details.</p>
            </div>
          )}
        </div>
      </div>

      {/* CMMS Sync Modal */}
      {cmmsExportModalOpen && selectedWorkOrder && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#121927] border border-slate-700 rounded-lg max-w-2xl w-full p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Download className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-semibold text-white">
                  Export Work Order to Enterprise CMMS
                </h3>
              </div>
              <button
                onClick={() => setCmmsExportModalOpen(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center gap-2 text-xs font-mono">
              <span className="text-slate-400">Select Integration Schema:</span>
              <button
                onClick={() => setExportFormat('sap')}
                className={`px-2.5 py-1 rounded cursor-pointer ${
                  exportFormat === 'sap' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold' : 'text-slate-400'
                }`}
              >
                SAP PM (BAPI ALM)
              </button>
              <button
                onClick={() => setExportFormat('maximo')}
                className={`px-2.5 py-1 rounded cursor-pointer ${
                  exportFormat === 'maximo' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold' : 'text-slate-400'
                }`}
              >
                IBM Maximo (MIF XML/JSON)
              </button>
              <button
                onClick={() => setExportFormat('json')}
                className={`px-2.5 py-1 rounded cursor-pointer ${
                  exportFormat === 'json' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold' : 'text-slate-400'
                }`}
              >
                REST API Payload
              </button>
            </div>

            <div className="bg-[#0b0f17] border border-slate-800 rounded p-3 font-mono text-xs text-slate-300 max-h-72 overflow-y-auto">
              <pre>{exportWorkOrderToCmms(selectedWorkOrder, exportFormat)}</pre>
            </div>

            <div className="flex items-center justify-between pt-2">
              <span className="text-xs text-slate-400 font-mono">
                API Endpoint: /api/v2/cmms/orders/sync
              </span>
              <button
                onClick={handleCopyCmms}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold rounded text-xs transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>{copySuccess ? 'Copied to Clipboard!' : 'Copy CMMS Payload'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* New Work Order Creation Modal */}
      {createModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <form onSubmit={handleCreateSubmit} className="bg-[#121927] border border-slate-700 rounded-lg max-w-lg w-full p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Wrench className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-semibold text-white">
                  Manual Work Order Creation
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setCreateModalOpen(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 font-medium mb-1">Target Equipment</label>
                <select
                  value={newAssetId}
                  onChange={(e) => setNewAssetId(e.target.value)}
                  className="w-full bg-[#0e1422] border border-slate-700 text-white rounded p-2 focus:outline-none focus:border-amber-500 font-mono"
                >
                  {assets.map((a) => (
                    <option key={a.id} value={a.id}>
                      [{a.tag}] {a.name} ({a.sector})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Work Order Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Coupling Inspection & Dynamic Laser Re-alignment"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-[#0e1422] border border-slate-700 text-white rounded p-2 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Priority</label>
                  <select
                    value={newPriority}
                    onChange={(e) => setNewPriority(e.target.value as any)}
                    className="w-full bg-[#0e1422] border border-slate-700 text-white rounded p-2 focus:outline-none focus:border-amber-500 font-mono"
                  >
                    <option value="P1_CRITICAL">P1_CRITICAL</option>
                    <option value="P2_HIGH">P2_HIGH</option>
                    <option value="P3_MEDIUM">P3_MEDIUM</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">Est. Downtime (Hours)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={newDowntimeHours}
                    onChange={(e) => setNewDowntimeHours(e.target.value)}
                    className="w-full bg-[#0e1422] border border-slate-700 text-white rounded p-2 focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Assigned Lead Technician</label>
                <input
                  type="text"
                  value={newTech}
                  onChange={(e) => setNewTech(e.target.value)}
                  className="w-full bg-[#0e1422] border border-slate-700 text-white rounded p-2 focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setCreateModalOpen(false)}
                className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold rounded text-xs cursor-pointer"
              >
                Create Work Order
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
