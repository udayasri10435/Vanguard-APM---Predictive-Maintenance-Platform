import React, { useState } from 'react';
import { Asset, Sector } from '../types';
import { Activity, ShieldAlert, Cpu, ArrowUpRight, DollarSign, Clock, Layers } from 'lucide-react';

interface OverviewViewProps {
  assets: Asset[];
  onSelectAsset: (asset: Asset) => void;
  onNavigateToTab: (tab: string) => void;
  onOpenFaultForAsset: (asset: Asset) => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  assets,
  onSelectAsset,
  onNavigateToTab,
  onOpenFaultForAsset,
}) => {
  const [selectedSector, setSelectedSector] = useState<Sector | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredAssets = assets.filter((asset) => {
    const matchesSector = selectedSector === 'all' || asset.sector === selectedSector;
    const matchesQuery =
      asset.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.tag.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.facility.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSector && matchesQuery;
  });

  const criticalCount = assets.filter((a) => a.status === 'critical').length;
  const warningCount = assets.filter((a) => a.status === 'warning').length;
  const nominalCount = assets.filter((a) => a.status === 'nominal').length;

  return (
    <div className="space-y-6">
      {/* Top Metric Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#121927] border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs uppercase tracking-wider font-semibold">Fleet Health Distribution</span>
            <Activity className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tabular-nums text-white">
              {nominalCount}/{assets.length}
            </span>
            <span className="text-xs text-emerald-400 font-mono">
              {Math.round((nominalCount / assets.length) * 100)}% Nominal
            </span>
          </div>
          <div className="mt-3 flex h-1.5 w-full rounded-full bg-slate-800 overflow-hidden">
            <div
              style={{ width: `${(nominalCount / assets.length) * 100}%` }}
              className="bg-emerald-500"
            />
            <div
              style={{ width: `${(warningCount / assets.length) * 100}%` }}
              className="bg-amber-500"
            />
            <div
              style={{ width: `${(criticalCount / assets.length) * 100}%` }}
              className="bg-rose-500"
            />
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px] font-mono text-slate-400">
            <span>{nominalCount} Nominal</span>
            <span className="text-amber-400">{warningCount} Warning</span>
            <span className="text-rose-400 font-semibold">{criticalCount} Critical</span>
          </div>
        </div>

        <div className="bg-[#121927] border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs uppercase tracking-wider font-semibold">Active Anomaly Flags</span>
            <ShieldAlert className="w-4 h-4 text-rose-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tabular-nums text-rose-400">
              {criticalCount + warningCount}
            </span>
            <span className="text-xs text-slate-400">ISO Zone C/D breaches</span>
          </div>
          <p className="text-xs text-slate-400 mt-2">
            {criticalCount} requiring immediate dispatch to prevent unrecoverable seizure.
          </p>
          <button
            onClick={() => onNavigateToTab('anomalies')}
            className="mt-3 text-xs text-amber-400 hover:text-amber-300 font-medium inline-flex items-center gap-1 cursor-pointer"
          >
            Review Anomaly Queue <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="bg-[#121927] border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs uppercase tracking-wider font-semibold">Mean Failure Lead Time</span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tabular-nums text-white">142 hrs</span>
            <span className="text-xs text-emerald-400 font-mono">+18% vs baseline</span>
          </div>
          <p className="text-xs text-slate-400 mt-2">
            Provides ample window for low-cost shift-based planned repairs before outage.
          </p>
          <div className="mt-3 text-[11px] text-slate-500 font-mono">
            Vibration Envelope & Acoustic Trigger
          </div>
        </div>

        <div className="bg-[#121927] border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs uppercase tracking-wider font-semibold">Prevented Loss & Downtime</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tabular-nums text-emerald-400">$385,500</span>
            <span className="text-xs text-slate-400">YTD avoided</span>
          </div>
          <p className="text-xs text-slate-400 mt-2">
            Based on 4 averted plant shutdowns and 2 saved turbine overhauls.
          </p>
          <button
            onClick={() => onNavigateToTab('roi')}
            className="mt-3 text-xs text-emerald-400 hover:text-emerald-300 font-medium inline-flex items-center gap-1 cursor-pointer"
          >
            Calculate Site ROI <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Sector Target Audience Banner */}
      <div className="bg-[#121927] border border-slate-800 rounded-lg p-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-semibold uppercase tracking-wider text-amber-400">
                Multi-Sector Reliability Architecture
              </span>
              <span className="text-slate-600 text-xs">·</span>
              <span className="text-xs text-slate-400">Plants · Utilities · Fleets</span>
            </div>
            <h2 className="text-lg font-semibold text-white">
              End-to-End Predictive Health Monitoring
            </h2>
            <p className="text-xs text-slate-400 mt-1 max-w-3xl leading-relaxed">
              Tailored telemetric algorithms for discrete manufacturing plants (pumps, CNC spindles, extruders),
              power generation and grid utilities (gas turbines, 500kV step-up transformers, wind nacelles),
              and heavy commercial fleets (haul trucks, freight rail, autonomous Class-8).
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => onNavigateToTab('gateway')}
              className="px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <Cpu className="w-3.5 h-3.5 text-amber-400" />
              <span>IoT Ingestion Console</span>
            </button>
            <button
              onClick={() => onNavigateToTab('work-orders')}
              className="px-3 py-1.5 text-xs font-medium text-slate-900 bg-amber-500 hover:bg-amber-400 rounded transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Automated Work Orders</span>
            </button>
          </div>
        </div>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
        <div className="flex items-center gap-1 bg-[#121927] p-1 rounded-lg border border-slate-800">
          <button
            onClick={() => setSelectedSector('all')}
            className={`px-3 py-1 text-xs font-medium rounded transition-colors cursor-pointer whitespace-nowrap ${
              selectedSector === 'all'
                ? 'bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All Monitored Assets ({assets.length})
          </button>
          <button
            onClick={() => setSelectedSector('plants')}
            className={`px-3 py-1 text-xs font-medium rounded transition-colors cursor-pointer whitespace-nowrap ${
              selectedSector === 'plants'
                ? 'bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Industrial Plants ({assets.filter((a) => a.sector === 'plants').length})
          </button>
          <button
            onClick={() => setSelectedSector('utilities')}
            className={`px-3 py-1 text-xs font-medium rounded transition-colors cursor-pointer whitespace-nowrap ${
              selectedSector === 'utilities'
                ? 'bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Power Utilities ({assets.filter((a) => a.sector === 'utilities').length})
          </button>
          <button
            onClick={() => setSelectedSector('fleets')}
            className={`px-3 py-1 text-xs font-medium rounded transition-colors cursor-pointer whitespace-nowrap ${
              selectedSector === 'fleets'
                ? 'bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Commercial Fleets ({assets.filter((a) => a.sector === 'fleets').length})
          </button>
        </div>

        <div className="w-full sm:w-72">
          <input
            type="text"
            placeholder="Search by tag, model, location..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#121927] border border-slate-800 rounded px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
          />
        </div>
      </div>

      {/* Asset Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredAssets.map((asset) => {
          const isCritical = asset.status === 'critical';
          const isWarning = asset.status === 'warning';

          return (
            <div
              key={asset.id}
              className={`bg-[#121927] border rounded-lg p-5 flex flex-col justify-between transition-all hover:border-slate-700 ${
                isCritical
                  ? 'border-rose-900/60 shadow-[0_0_15px_rgba(244,63,94,0.06)]'
                  : isWarning
                  ? 'border-amber-900/50'
                  : 'border-slate-800'
              }`}
            >
              <div>
                {/* Header row: Tag and status text */}
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <span className="font-mono text-xs font-bold text-amber-400 tracking-wider">
                      {asset.tag}
                    </span>
                    <span className="text-slate-600 mx-1.5">·</span>
                    <span className="text-xs text-slate-400 capitalize">
                      {asset.sector}
                    </span>
                  </div>
                  <div className="text-right">
                    <span
                      className={`text-xs font-mono font-semibold tracking-wide ${
                        isCritical
                          ? 'text-rose-400'
                          : isWarning
                          ? 'text-amber-400'
                          : 'text-emerald-400'
                      }`}
                    >
                      {asset.status.toUpperCase()}
                    </span>
                    <span className="text-slate-500 text-[11px] block font-mono">
                      {asset.isoZone}
                    </span>
                  </div>
                </div>

                <h3 className="text-sm font-semibold text-white line-clamp-1">
                  {asset.name}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5 line-clamp-1">
                  {asset.facility} — {asset.location}
                </p>

                {/* Telemetry Matrix (clean tabular figures) */}
                <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-slate-800/80">
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase">Vibration</span>
                    <span
                      className={`text-xs font-mono font-semibold tabular-nums ${
                        asset.telemetry.vibrationRms > 4.5
                          ? isCritical
                            ? 'text-rose-400'
                            : 'text-amber-400'
                          : 'text-slate-200'
                      }`}
                    >
                      {asset.telemetry.vibrationRms} <span className="text-[10px] text-slate-400 font-normal">mm/s</span>
                    </span>
                  </div>

                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase">Bearing Temp</span>
                    <span
                      className={`text-xs font-mono font-semibold tabular-nums ${
                        asset.telemetry.bearingTemp > 75
                          ? isCritical
                            ? 'text-rose-400'
                            : 'text-amber-400'
                          : 'text-slate-200'
                      }`}
                    >
                      {asset.telemetry.bearingTemp}°C
                    </span>
                  </div>

                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase">Acoustic HF</span>
                    <span
                      className={`text-xs font-mono font-semibold tabular-nums ${
                        asset.telemetry.acousticUltrasound > 45 ? 'text-amber-400' : 'text-slate-200'
                      }`}
                    >
                      {asset.telemetry.acousticUltrasound} <span className="text-[10px] text-slate-400 font-normal">dB</span>
                    </span>
                  </div>
                </div>

                {/* RUL & Failure Mode Risk */}
                <div className="mt-3 pt-3 border-t border-slate-800/60">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="text-slate-400 text-[11px]">Est. Remaining Useful Life</span>
                    <span className="font-mono text-xs font-semibold tabular-nums text-slate-200">
                      {asset.rulHours} hrs
                    </span>
                  </div>
                  <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                    <div
                      style={{ width: `${Math.min(100, Math.max(8, (asset.rulHours / 2000) * 100))}%` }}
                      className={`h-full ${
                        asset.rulHours < 50
                          ? 'bg-rose-500'
                          : asset.rulHours < 200
                          ? 'bg-amber-500'
                          : 'bg-emerald-500'
                      }`}
                    />
                  </div>
                  <p className="text-[11px] text-slate-400 mt-2 line-clamp-1 italic">
                    {asset.failureModeRisk}
                  </p>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center justify-between gap-2 mt-4 pt-3 border-t border-slate-800/80">
                <button
                  onClick={() => onOpenFaultForAsset(asset)}
                  className="text-xs text-slate-400 hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Test Anomaly
                </button>
                <button
                  onClick={() => {
                    onSelectAsset(asset);
                    onNavigateToTab('twin');
                  }}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded text-xs font-medium transition-colors inline-flex items-center gap-1 cursor-pointer"
                >
                  <span>Digital Twin</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
