import React, { useState, useEffect } from 'react';
import { Asset, AnomalyAlert, WorkOrder } from './types';
import { INITIAL_ASSETS, INITIAL_ALERTS, INITIAL_WORK_ORDERS } from './data/mockAssets';
import { simulateAssetTick, injectFaultIntoAsset } from './utils/telemetryEngine';
import { Header } from './components/Header';
import { OverviewView } from './components/OverviewView';
import { DigitalTwinView } from './components/DigitalTwinView';
import { AnomalyEngineView } from './components/AnomalyEngineView';
import { WorkOrdersView } from './components/WorkOrdersView';
import { IotGatewayView } from './components/IotGatewayView';
import { RoiCalculatorView } from './components/RoiCalculatorView';
import { FaultInjectorModal } from './components/FaultInjectorModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [assets, setAssets] = useState<Asset[]>(INITIAL_ASSETS);
  const [selectedAsset, setSelectedAsset] = useState<Asset>(INITIAL_ASSETS[0]);
  const [alerts, setAlerts] = useState<AnomalyAlert[]>(INITIAL_ALERTS);
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>(INITIAL_WORK_ORDERS);
  const [isStreaming, setIsStreaming] = useState<boolean>(true);

  // Fault Injector Modal
  const [faultModalOpen, setFaultModalOpen] = useState(false);
  const [targetAssetForFault, setTargetAssetForFault] = useState<Asset | null>(null);

  // Real-time live IoT telemetry stream tick
  useEffect(() => {
    if (!isStreaming) return;

    const interval = setInterval(() => {
      setAssets((prevAssets) =>
        prevAssets.map((asset) => {
          const updated = simulateAssetTick(asset);
          // If this is currently the selected digital twin asset, sync it
          if (updated.id === selectedAsset.id) {
            setSelectedAsset(updated);
          }
          return updated;
        })
      );
    }, 2000);

    return () => clearInterval(interval);
  }, [isStreaming, selectedAsset.id]);

  const handleInjectFault = (assetId: string, faultType: string) => {
    setAssets((prev) =>
      prev.map((a) => {
        if (a.id === assetId) {
          const mutated = injectFaultIntoAsset(a, faultType);
          if (mutated.id === selectedAsset.id) {
            setSelectedAsset(mutated);
          }

          // If a fault was injected (not clear), check if we need to add an alert
          if (faultType !== 'clear_fault') {
            const existingAlert = alerts.find((al) => al.assetId === a.id && al.status === 'active');
            if (!existingAlert) {
              const newAlert: AnomalyAlert = {
                id: `ALT-${Math.floor(9100 + Math.random() * 800)}`,
                assetId: a.id,
                assetName: a.name,
                assetTag: a.tag,
                sector: a.sector,
                severity: mutated.status === 'critical' ? 'critical' : 'warning',
                isoZone: mutated.isoZone,
                detectedAt: 'Just now',
                metricTrigger: 'Dynamic Harmonic BPFI Spike & Thermal Exceedance',
                triggerValue: `${mutated.telemetry.vibrationRms} mm/s RMS`,
                threshold: '4.50 mm/s RMS',
                confidence: 96,
                status: 'active',
                failureHypothesis: mutated.failureModeRisk,
                estimatedLeadTimeToFailureHours: mutated.rulHours,
              };
              setAlerts((curr) => [newAlert, ...curr]);
            }
          }

          return mutated;
        }
        return a;
      })
    );
  };

  const handleUpdateAssetTelemetry = (assetId: string, telemetryPatch: any) => {
    setAssets((prev) =>
      prev.map((a) => {
        if (a.id === assetId) {
          const updated = {
            ...a,
            telemetry: {
              ...a.telemetry,
              ...telemetryPatch,
            },
          };
          if (updated.id === selectedAsset.id) {
            setSelectedAsset(updated);
          }
          return updated;
        }
        return a;
      })
    );
  };

  const handleUpdateWorkOrderStatus = (id: string, newStatus: WorkOrder['status']) => {
    setWorkOrders((prev) =>
      prev.map((wo) => (wo.id === id ? { ...wo, status: newStatus } : wo))
    );
  };

  const handleAddWorkOrder = (newWo: WorkOrder) => {
    setWorkOrders((prev) => [newWo, ...prev]);
  };

  const criticalAlertCount = alerts.filter((a) => a.severity === 'critical' && a.status === 'active').length;

  return (
    <div className="min-h-screen bg-[#0b0f17] text-slate-100 font-sans flex flex-col selection:bg-amber-500/20 selection:text-amber-200">
      {/* Top Bar adhering to Top Bar Contract */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isStreaming={isStreaming}
        setIsStreaming={setIsStreaming}
        onOpenFaultModal={() => {
          setTargetAssetForFault(null);
          setFaultModalOpen(true);
        }}
        criticalAlertCount={criticalAlertCount}
      />

      {/* Main Viewport Container */}
      <main className="flex-1 max-w-[1600px] w-full mx-auto px-6 py-8">
        {activeTab === 'overview' && (
          <OverviewView
            assets={assets}
            onSelectAsset={(asset) => setSelectedAsset(asset)}
            onNavigateToTab={(tab) => setActiveTab(tab)}
            onOpenFaultForAsset={(asset) => {
              setTargetAssetForFault(asset);
              setFaultModalOpen(true);
            }}
          />
        )}

        {activeTab === 'twin' && (
          <DigitalTwinView
            asset={selectedAsset}
            assets={assets}
            onSelectAsset={(asset) => setSelectedAsset(asset)}
            onNavigateToAnomaliesForAsset={() => setActiveTab('anomalies')}
            isStreaming={isStreaming}
          />
        )}

        {activeTab === 'anomalies' && (
          <AnomalyEngineView
            alerts={alerts}
            assets={assets}
            onSelectAssetForTwin={(asset) => {
              setSelectedAsset(asset);
              setActiveTab('twin');
            }}
            onAddWorkOrder={handleAddWorkOrder}
            targetAssetForDiagnosis={selectedAsset}
          />
        )}

        {activeTab === 'work-orders' && (
          <WorkOrdersView
            workOrders={workOrders}
            assets={assets}
            onUpdateWorkOrderStatus={handleUpdateWorkOrderStatus}
            onCreateWorkOrder={handleAddWorkOrder}
          />
        )}

        {activeTab === 'gateway' && (
          <IotGatewayView
            assets={assets}
            isStreaming={isStreaming}
            onUpdateAssetTelemetry={handleUpdateAssetTelemetry}
          />
        )}

        {activeTab === 'roi' && <RoiCalculatorView />}
      </main>

      {/* Quiet Corporate / Engineering Footer adhering to anti-slop rules */}
      <footer className="border-t border-slate-800/80 bg-[#0e1422] py-6 px-6 mt-12">
        <div className="max-w-[1600px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 font-mono">
          <div className="flex items-center gap-3">
            <span className="font-semibold text-slate-400">Vanguard APM</span>
            <span>·</span>
            <span>ISO 10816-3 Condition Monitoring</span>
            <span>·</span>
            <span>Industrial IoT Gateway v2.4</span>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setActiveTab('overview')}
              className="hover:text-slate-300 transition-colors cursor-pointer"
            >
              Fleet Overview
            </button>
            <button
              onClick={() => setActiveTab('twin')}
              className="hover:text-slate-300 transition-colors cursor-pointer"
            >
              Digital Twins
            </button>
            <button
              onClick={() => setActiveTab('gateway')}
              className="hover:text-slate-300 transition-colors cursor-pointer"
            >
              IoT Gateway
            </button>
            <button
              onClick={() => setActiveTab('roi')}
              className="hover:text-slate-300 transition-colors cursor-pointer"
            >
              Economics & ROI
            </button>
          </div>
        </div>
      </footer>

      {/* Anomaly & Fault Injector Modal */}
      <FaultInjectorModal
        isOpen={faultModalOpen}
        onClose={() => setFaultModalOpen(false)}
        assets={assets}
        targetAsset={targetAssetForFault}
        onInjectFault={handleInjectFault}
      />
    </div>
  );
}
