import { Asset, IsoZone, TelemetryHistoryPoint } from '../types';

export function calculateIsoZone(vibrationRms: number): IsoZone {
  if (vibrationRms < 2.3) return 'Zone A';
  if (vibrationRms < 4.5) return 'Zone B';
  if (vibrationRms < 7.1) return 'Zone C';
  return 'Zone D';
}

export function computeAnomalyIndex(asset: Asset): number {
  const vibDelta = Math.max(0, (asset.telemetry.vibrationRms - asset.baseline.vibrationRms) / asset.baseline.vibrationRms);
  const tempDelta = Math.max(0, (asset.telemetry.bearingTemp - asset.baseline.bearingTemp) / asset.baseline.bearingTemp);
  const acousticDelta = Math.max(0, (asset.telemetry.acousticUltrasound - asset.baseline.acousticUltrasound) / asset.baseline.acousticUltrasound);

  const rawScore = (vibDelta * 40) + (tempDelta * 35) + (acousticDelta * 25);
  return Math.min(100, Math.round(rawScore));
}

export function generateInitialHistory(asset: Asset, pointsCount: number = 30): TelemetryHistoryPoint[] {
  const points: TelemetryHistoryPoint[] = [];
  const now = Date.now();
  const stepMs = 5000; // 5 seconds per tick

  for (let i = pointsCount - 1; i >= 0; i--) {
    const time = new Date(now - i * stepMs);
    const progress = 1 - (i / pointsCount); // recent is higher if anomalous

    // Slight variance
    const noise = (Math.random() - 0.5) * 0.15;
    const isDegrading = asset.status !== 'nominal';
    const driftFactor = isDegrading ? (progress * 0.35) : 0;

    const vib = Math.max(0.2, Number((asset.telemetry.vibrationRms * (1 - driftFactor + noise)).toFixed(2)));
    const temp = Math.max(20, Number((asset.telemetry.bearingTemp * (1 - (driftFactor * 0.5) + noise * 0.5)).toFixed(1)));
    const acoustic = Math.max(10, Number((asset.telemetry.acousticUltrasound * (1 - driftFactor + noise)).toFixed(1)));
    const pressure = Math.max(1, Number((asset.telemetry.oilPressure * (1 + noise * 0.2)).toFixed(2)));

    const anomalyScore = Math.min(100, Math.max(5, Math.round((asset.status === 'critical' ? 75 : asset.status === 'warning' ? 45 : 12) + noise * 20)));

    points.push({
      timestamp: time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      vibrationRms: vib,
      bearingTemp: temp,
      acousticUltrasound: acoustic,
      oilPressure: pressure,
      anomalyScore,
    });
  }

  return points;
}

export function simulateAssetTick(asset: Asset): Asset {
  // Random small fluctuation
  const jitter = (Math.random() - 0.49) * 0.08;
  const tempJitter = (Math.random() - 0.49) * 0.18;

  let newVib = Math.max(0.4, Number((asset.telemetry.vibrationRms + jitter).toFixed(2)));
  let newTemp = Math.max(25, Number((asset.telemetry.bearingTemp + tempJitter).toFixed(1)));
  let newAcoustic = Math.max(10, Number((asset.telemetry.acousticUltrasound + (Math.random() - 0.49) * 0.4).toFixed(1)));
  let newPressure = Math.max(1.0, Number((asset.telemetry.oilPressure + (Math.random() - 0.49) * 0.05).toFixed(2)));

  const newIso = calculateIsoZone(newVib);

  let status = asset.status;
  if (newIso === 'Zone D' || newTemp > 86) {
    status = 'critical';
  } else if (newIso === 'Zone C' || newTemp > 72) {
    status = 'warning';
  } else if (newIso === 'Zone A' || newIso === 'Zone B') {
    status = 'nominal';
  }

  // Update sensor points
  const updatedSensors = asset.sensorPoints.map((sp) => {
    let val = sp.value;
    if (sp.type === 'vibration') val = newVib;
    if (sp.type === 'temperature') val = newTemp;
    if (sp.type === 'acoustic') val = newAcoustic;
    if (sp.type === 'pressure') val = newPressure;

    let sStatus: 'nominal' | 'warning' | 'critical' = 'nominal';
    if (val > sp.nominalRange[1] * 1.3) sStatus = 'critical';
    else if (val > sp.nominalRange[1]) sStatus = 'warning';

    return {
      ...sp,
      value: Number(val.toFixed(1)),
      status: sStatus,
    };
  });

  return {
    ...asset,
    status,
    isoZone: newIso,
    telemetry: {
      ...asset.telemetry,
      vibrationRms: newVib,
      bearingTemp: newTemp,
      acousticUltrasound: newAcoustic,
      oilPressure: newPressure,
    },
    sensorPoints: updatedSensors,
  };
}

export function injectFaultIntoAsset(asset: Asset, faultType: string): Asset {
  let vib = asset.telemetry.vibrationRms;
  let temp = asset.telemetry.bearingTemp;
  let acoustic = asset.telemetry.acousticUltrasound;
  let pressure = asset.telemetry.oilPressure;
  let failureMode = asset.failureModeRisk;
  let rul = asset.rulHours;

  if (faultType === 'bearing_inner_spall') {
    vib = 8.65;
    temp = 89.2;
    acoustic = 71.0;
    failureMode = 'Severe Inner Race Bearing Spall (BPFI Excitation)';
    rul = 14;
  } else if (faultType === 'rotor_misalignment') {
    vib = 7.42;
    temp = 82.5;
    acoustic = 54.0;
    failureMode = 'Dynamic Coupling Angular Misalignment (2X Harmonic)';
    rul = 38;
  } else if (faultType === 'cavitation_recirculation') {
    vib = 6.95;
    pressure = 1.9;
    acoustic = 78.4;
    failureMode = 'Impeller Cavitation & High-Frequency Pressure Shock';
    rul = 28;
  } else if (faultType === 'thermal_lube_breakdown') {
    temp = 98.4;
    vib = 7.8;
    pressure = 1.6;
    failureMode = 'Lubrication Film Failure & Micro-Weld Metal Shearing';
    rul = 8;
  } else if (faultType === 'clear_fault') {
    vib = asset.baseline.vibrationRms;
    temp = asset.baseline.bearingTemp;
    acoustic = asset.baseline.acousticUltrasound;
    pressure = asset.baseline.oilPressure;
    failureMode = 'Normal Operational Window';
    rul = 2400;
  }

  const iso = calculateIsoZone(vib);
  const status = iso === 'Zone D' || temp > 85 ? 'critical' : iso === 'Zone C' || temp > 70 ? 'warning' : 'nominal';

  return {
    ...asset,
    status,
    isoZone: iso,
    failureModeRisk: failureMode,
    rulHours: rul,
    telemetry: {
      ...asset.telemetry,
      vibrationRms: vib,
      bearingTemp: temp,
      acousticUltrasound: acoustic,
      oilPressure: pressure,
    },
  };
}

export function exportWorkOrderToCmms(workOrder: any, format: 'sap' | 'maximo' | 'json'): string {
  if (format === 'sap') {
    return JSON.stringify({
      SAP_BAPI_ALM_ORDER_MAINTAIN: {
        HEADER: {
          ORDERID: workOrder.id,
          ORDER_TYPE: 'PM02_PREDICTIVE_MAINT',
          EQUIPMENT: workOrder.assetTag,
          PRIORITY: workOrder.priority === 'P1_CRITICAL' ? '1_VERY_HIGH' : '2_HIGH',
          SHORT_TEXT: workOrder.title,
          START_DATE: new Date().toISOString().split('T')[0],
        },
        OPERATIONS: workOrder.steps?.map((step: string, i: number) => ({
          ACTIVITY: `00${(i + 1) * 10}`,
          CONTROL_KEY: 'PM01',
          DESCRIPTION: step,
          DURATION_NORMAL: (workOrder.estimatedDowntimeHours / (workOrder.steps.length || 1)).toFixed(1),
          WORK_CNTR: 'MECH_MAINT',
        })),
        COMPONENTS: workOrder.partsRequired?.map((part: any, i: number) => ({
          ITEM_NO: `00${(i + 1) * 10}`,
          MATERIAL: part.partNumber,
          DESCRIPTION: part.description,
          REQUIREMENT_QUANTITY: part.qty,
        })),
      },
    }, null, 2);
  }

  if (format === 'maximo') {
    return JSON.stringify({
      MaximoWorkOrderSync: {
        WONUM: workOrder.id,
        ASSETNUM: workOrder.assetTag,
        DESCRIPTION: workOrder.title,
        WOPRIORITY: workOrder.priority === 'P1_CRITICAL' ? 1 : 2,
        STATUS: 'WAPPR_DISPATCHED',
        ESTDUR: workOrder.estimatedDowntimeHours,
        LEAD: workOrder.assignedTechnician,
        REPORTEDBY: 'VANGUARD_APM_AI_ENGINE',
        WORKTYPE: 'PdM',
        WOTASKS: workOrder.steps?.map((step: string, i: number) => ({
          TASKID: i + 1,
          DESCRIPTION: step,
        })),
      },
    }, null, 2);
  }

  return JSON.stringify(workOrder, null, 2);
}
