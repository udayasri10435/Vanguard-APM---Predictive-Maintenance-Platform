export type Sector = 'plants' | 'utilities' | 'fleets';

export type AssetStatus = 'nominal' | 'warning' | 'critical' | 'offline';

export type IsoZone = 'Zone A' | 'Zone B' | 'Zone C' | 'Zone D';

export type Priority = 'P1_CRITICAL' | 'P2_HIGH' | 'P3_MEDIUM';

export interface SensorPoint {
  id: string;
  name: string;
  type: 'vibration' | 'temperature' | 'acoustic' | 'pressure' | 'current';
  x: number; // percentage in SVG coordinate
  y: number;
  value: number;
  unit: string;
  nominalRange: [number, number];
  status: 'nominal' | 'warning' | 'critical';
}

export interface Asset {
  id: string;
  name: string;
  tag: string;
  sector: Sector;
  sectorLabel: string;
  type: string;
  facility: string;
  location: string;
  status: AssetStatus;
  criticality: Priority;
  operatingHours: number;
  lastMaintainedDate: string;
  rulHours: number; // Remaining Useful Life
  failureModeRisk: string;
  isoZone: IsoZone;
  telemetry: {
    vibrationRms: number; // mm/s
    peakVibration: number; // g
    bearingTemp: number; // °C
    oilPressure: number; // bar
    acousticUltrasound: number; // dB
    motorCurrentAmps: number; // A
    rpm: number;
    flowRate?: number; // m3/h
  };
  baseline: {
    vibrationRms: number;
    bearingTemp: number;
    oilPressure: number;
    acousticUltrasound: number;
    motorCurrentAmps: number;
  };
  harmonics: {
    runningSpeed1X: number;
    misalignment2X: number;
    bearingPassInnerBPFI: number;
    gearMeshFrequencyGMF: number;
  };
  sensorPoints: SensorPoint[];
}

export interface TelemetryHistoryPoint {
  timestamp: string;
  vibrationRms: number;
  bearingTemp: number;
  acousticUltrasound: number;
  oilPressure: number;
  anomalyScore: number;
}

export interface AnomalyAlert {
  id: string;
  assetId: string;
  assetName: string;
  assetTag: string;
  sector: Sector;
  severity: 'critical' | 'warning';
  isoZone: IsoZone;
  detectedAt: string;
  metricTrigger: string;
  triggerValue: string;
  threshold: string;
  confidence: number;
  status: 'active' | 'triaged' | 'work_order_generated' | 'resolved';
  failureHypothesis: string;
  estimatedLeadTimeToFailureHours: number;
}

export interface WorkOrderPart {
  partNumber: string;
  description: string;
  qty: number;
  inStock: boolean;
  unitCostUSD: number;
}

export interface WorkOrder {
  id: string;
  assetId: string;
  assetName: string;
  assetTag: string;
  sector: Sector;
  title: string;
  priority: Priority;
  status: 'draft' | 'dispatched' | 'in_progress' | 'completed';
  createdAt: string;
  dueInHours: number;
  assignedTechnician: string;
  technicianRole: string;
  technicianCert: string;
  estimatedDowntimeHours: number;
  estimatedSavingsUSD: number;
  rootCauseSummary: string;
  partsRequired: WorkOrderPart[];
  isoStandardProcedure: string;
  steps: string[];
}

export interface IngestionPacket {
  id: string;
  timestamp: string;
  assetId: string;
  protocol: 'MQTT_v5' | 'OPC_UA' | 'MODBUS_TCP' | 'SPARKPLUG_B';
  payloadSizeKb: number;
  latencyMs: number;
  anomalyScore: number;
  status: 'ACCEPTED' | 'THRESHOLD_WARNING' | 'ALERT_TRIPPED';
}

export interface AiDiagnosisResult {
  faultCategory: string;
  confidenceScore: number;
  estimatedRemainingUsefulLifeHours: number;
  isoSeverityGrade: string;
  rootCauseAnalysis: string;
  recommendedActions: string[];
  automatedWorkOrder?: {
    title: string;
    priority: Priority;
    estimatedDowntimeHours: number;
    requiredTechnicianCert: string;
    partsRequired: string[];
    estimatedCostSavedUSD: number;
  };
}
